# Ccache 4.13.6 {#_ccache_4_13_6}

Release date: 2026-05-04

## Bug fixes and improvements {#_bug_fixes_and_improvements}

-   Fixed a potential manifest/result cache key collision in MSVC depend
    mode when compiling a source file with no included files.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved robustness when parsing cache entry data structures.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements}

-   Changed the `remote_helper` test suite to skip gracefully when the
    storage test helper is unavailable, avoiding failures when testing a
    system-installed ccache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.13.5 {#_ccache_4_13_5}

Release date: 2026-04-26

## Bug fixes and improvements {#_bug_fixes_and_improvements_2}

-   Increased default storage helper data and request timeouts to 10
    seconds and 1 minute respectively, improving robustness on heavily
    loaded systems.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved robustness when connecting to newly spawned storage helpers
    by waiting longer for them to accept connections.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Synchronized writing to the stats log file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added logging of the PID of spawned storage helpers on Windows too.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements}

-   Added include guards to bundled CMake find modules, avoiding
    problems when they are included multiple times.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements}

-   Moved the description of timeout suffixes to the correct place in
    the documentation.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.13.4 {#_ccache_4_13_4}

Release date: 2026-04-19

## New deliverables {#_new_deliverables}

-   Added musl static binary release for Linux riscv64.\
    [*\[contributed by Ludovic Henry\]*]{.small}

# Ccache 4.13.3 {#_ccache_4_13_3}

Release date: 2026-04-12

## New deliverables {#_new_deliverables_2}

-   Added glibc binary release for Linux riscv64.\
    [*\[contributed by Ludovic Henry\]*]{.small}

## Bug fixes and improvements {#_bug_fixes_and_improvements_3}

-   Fixed handling of empty responses from remote storage backends: a
    response with an empty body is now treated as a storage error rather
    than a cache miss.\
    [*\[contributed by Björn Svensson\]*]{.small}

-   Fixed PCH invalidation when the MSVC toolset is updated.\
    [*\[contributed by Philipp Kolberg\]*]{.small}

-   Fixed `base_dir` path rewriting when using MSVC's `/Yc` option:
    paths are no longer rewritten to relative when creating a
    precompiled header, since MSVC then does not like relative paths for
    the `/Yc` and `/FI` arguments.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed handling of a directory-less path to the MSVC `/FI` option.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for `-fsanitize-ignorelist` (which replaced
    `-fsanitize-blacklist` in Clang 13).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed detection of type for compiler with `.` in the name (e.g.
    `hppa2.0-unknown-linux-gnu-gcc`).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed `install.sh` to correctly use `sysconfdir` and other
    configuration variables from the Makefile.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_2}

-   Changed `cmake/FindCppHttplib.cmake` to use settings from the
    system's CMake config if available, supporting systems where
    cpp-httplib is not provided as a header-only library.\
    [*\[contributed by Jiri Slaby\]*]{.small}

# Ccache 4.13.2 {#_ccache_4_13_2}

Release date: 2026-03-22

## New deliverables {#_new_deliverables_3}

-   Added `tar.gz` archives for Linux binary releases.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added installation script for Linux binary releases.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes and improvements {#_bug_fixes_and_improvements_4}

-   Fixed LTO handling when `-fno-lto` follows `-flto`: LTO is now
    properly disabled in this case.\
    [*\[contributed by Kristian Sloth Lauszus\]*]{.small}

-   Fixed crash when using MSVC `/Yc` without `/Fp`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed rewriting of MSVC `/FI` argument to a relative path when
    `base_dir` is set.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved robustness when parsing broken cache entry files.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed atime/mtime restoration when recompressing a file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_2}

-   Fixed test failures for `remote_helper` tests when `$PWD` is long.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved robustness of `remote_helper` tests on slow systems.\
    [*\[contributed by Maksym Sobolyev\]*]{.small}

-   Relaxed `util::exec_to_string` unit test for portability.\
    [*\[contributed by Maksym Sobolyev\]*]{.small}

-   Removed unnecessary, compiler-specific checks in `-flto` tests.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.13.1 {#_ccache_4_13_1}

Release date: 2026-03-09

## Bug fixes and improvements {#_bug_fixes_and_improvements_5}

-   Fixed handling of extensionless input files passed with
    `-x assembler` (regression in 4.13).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed a crash when searching for a storage helper next to the ccache
    executable.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed atime restoration when the recompressor fails to read a file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved storage helper lookup order to prefer libexec directories
    over `PATH`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved reliability of finding the ccache executable path by using
    OS-specific APIs instead of relying on `argv[0]`, which is not
    guaranteed to reflect the actual executable location.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved handling of `-fstack-usage` and `-fcallgraph-info` output
    files when LTO is used: ccache now correctly skips looking for `.su`
    and `.ci` files that are not generated during compilation with LTO.\
    [*\[contributed by Kristian Sloth Lauszus\]*]{.small}

## Build fixes {#_build_fixes}

-   Fixed build on systems that have `utimes(2)` but not
    `utimensat(2)`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed `mktemp(1)` calls in build scripts to pass a template argument
    for portability to macOS/BSD.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.13 {#_ccache_4_13}

Release date: 2026-03-05

## Upgrade notes {#_upgrade_notes}

-   A C++20-capable compiler is now required to build ccache from
    source. Minimum supported compiler versions are GCC 10, Clang 12 and
    Apple Clang 10.

-   Caching MSVC (`cl.exe`) compilations is now officially supported.

## New deliverables {#_new_deliverables_4}

-   Added Linux binary releases statically linked with
    [musl](https://musl.libc.org).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Removed deliverables {#_removed_deliverables}

-   Discontinued 32-bit Windows binary releases.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## New features and improvements {#_new_features_and_improvements}

-   Added support for [remote storage
    helpers](https://ccache.dev/storage-helpers.html): long-lived local
    helper processes spawned on demand for communicating with remote
    storage servers. Storage helpers allow support for new storage
    protocols to be developed and released independently of ccache.
    Built-in support for HTTP and Redis will likely be removed in a
    future release.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for directory-specific configuration files. Ccache now
    looks for a `ccache.conf` file in the current working directory and
    its parent directories, enabling per-project configuration without
    modifying the user's cache-specific config file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added `msvc_utf8` config option to allow disabling `/utf-8` for MSVC
    when using the fallback method of parsing preprocessed output.\
    [*\[contributed by Max Winkler\]*]{.small}

-   Added support for caching distributed ThinLTO for Clang.\
    [*\[contributed by GitHub user zcfh\]*]{.small}

-   Added support for caching MSVC `/sourceDependencies` file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added handling of Apple Clang's `-index-unit-output-path` option.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved compiler detection on macOS by resolving the actual
    compiler via `$DEVELOPER_DIR` or `xcode-select` when
    `/usr/bin/clang(++)` shims that redirect to different compilers are
    used.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for rewriting `-fcoverage-compilation-dir` and
    `-fcoverage-prefix-map` absolute paths (similar to existing
    `base_dir` rewriting).\
    [*\[contributed by Evgeniy Isaev\]*]{.small}

-   Added support for rewriting absolute paths in `-fsanitize-blacklist`
    option arguments.\
    [*\[contributed by Diego Alonso\]*]{.small}

-   Added support for multi-line configuration values.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved file copy performance by using `copy_file_range(2)` when
    available.\
    [*\[contributed by Oleg Sidorkin\]*]{.small}

-   Added `h`, `m` and `ms` as accepted time unit suffixes for
    `--evict-older-than` (in addition to the existing `d` and `s`).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Merged `--recompress-threads` and `--trim-recompress-threads`
    options into `--threads`. The old options are still accepted for
    backward compatibility.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved performance of `-x`/`--show-compression` and
    `-X`/`--recompress` by using threads in parallel.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added logging of errors and file size changes when recompressing
    cache files.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes}

-   Fixed use of monotonic clock for spin locks in the inode cache
    code.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_3}

-   Fixed conditional enabling of the assembler language in CMake to
    avoid enabling both ASM and ASM_MASM on the same platform.\
    [*\[contributed by Steffen Winter\]*]{.small}

-   Fixed inclusion of `config.h` to only apply to C and C++ compilation
    units, not assembler files. This avoids a problem when building with
    Clang on Windows.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Disabled legacy ZSTD support when compiling ZSTD from source to
    avoid `-Wmaybe-uninitialized` warnings.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Removed check for (on POSIX) mandatory `spawn.h` header.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_2}

-   Added generation of documentation in Markdown format.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_3}

-   Added a basic integration test suite for MSVC.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added an integration test for `--serialize-diagnostics`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for Valkey in the `remote_redis` test suite.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed `-march=native` test to work reliably on hybrid CPU systems.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.12.3 {#_ccache_4_12_3}

Release date: 2026-02-07

## Bug fixes {#_bug_fixes_2}

-   Fixed hashing of CWD parts of `-march=native` expansion for Clang.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed lookup of `-march=native` expansion line for GCC on Windows.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed rewriting of "inlined from" messages when
    `absolute_paths_in_stderr` is enabled.\
    [*\[contributed by Enrico Seiler\]*]{.small}

-   Added support for NVCC long option alternatives to
    `-M`/`-MD`/`-MF`/`-MM`/`-MMD`/`-MT`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed setting of `UNCACHED_ERR_FD` environment variable so that it
    is only set when executing the compiler.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed leaking of inode cache file descriptor to executed programs.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed errno check for some system calls.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_3}

-   Fixed links to installation guide in README.\
    [*\[contributed by Evgeniy Isaev\]*]{.small}

# Ccache 4.12.2 {#_ccache_4_12_2}

Release date: 2025-11-26

## Bug fixes {#_bug_fixes_3}

-   Improved robustness against filesystem path encoding problems on
    Windows.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed removal of mismatching manifest file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build fixes {#_build_fixes_2}

-   Fixed build of BLAKE3 for little-endian aarch64 with CMake
    3.18/3.19.\
    [*\[contributed by J. Neuschäfer\]*]{.small}

-   Added linking with libsocket on SunOS/Illumos.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_4}

-   Fixed profiling_clang test.\
    [*\[contributed by Evgeniy Isaev\]*]{.small}

## Documentation improvements {#_documentation_improvements_4}

-   Reconciled max-size suffixes in documentation.\
    [*\[contributed by Andrej Zhilenkov\]*]{.small}

-   Improved documentation on statistics counters and --zero-stats.\
    [*\[contributed by Joel Rosdahl and Otto Kekäläinen\]*]{.small}

-   Added note that sloppiness values can be whitespace-separated.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Updated URLs in manual and news.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Other {#_other}

-   Fixed default sysconf dir in Linux binary releases.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed typo in CcacheVersion.cmake.\
    [*\[contributed by Andrej Zhilenkov\]*]{.small}

-   Updated C++ standard in .clang-format.\
    [*\[contributed by Evgeniy Isaev\]*]{.small}

# Ccache 4.12.1 {#_ccache_4_12_1}

Release date: 2025-10-01

## Bug fixes {#_bug_fixes_4}

-   Fixed handling of `-Xarch_host`/`-Xarch_device` options.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed saving of current position in fallocate fallback code.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed handling of `ENOENT` when trying to break a lockfile lock.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build fixes {#_build_fixes_3}

-   Added missing `return` in `copy_file_impl` fallback code, fixing a
    compilation error with tl::expected ≥ 1.2.0 on non-Apple platforms
    where `sendfile(2)` is unavailable.\
    [*\[contributed by GitHub user kingiler\]*]{.small}

## Other {#_other_2}

-   Added missing documentation files to Linux/macOS binary releases.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.12 {#_ccache_4_12}

Release date: 2025-09-14

## Upgrade notes {#_upgrade_notes_2}

-   CMake version 3.18 or higher is now needed to build ccache.

## New deliverables {#_new_deliverables_5}

-   Added binary releases for Linux aarch64 and Windows aarch64.\
    [*\[contributed by Joel Rosdahl and Martin Storsjö\]*]{.small}

## New features and improvements {#_new_features_and_improvements_2}

-   Enabled awareness of long paths and wide characters on Windows by
    embedding an application manifest in `ccache.exe`.\
    [*\[contributed by Morten Engelhardt Olsen and Joel
    Rosdahl\]*]{.small}

-   Added support for multiple directories in
    `base_dir`/`CCACHE_BASEDIR`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for Clang compiling CUDA code.\
    [*\[contributed by GitHub user w169Nq169\]*]{.small}

-   Added support `-x cu` and `-x cuda` in Clang CUDA mode.\
    [*\[contributed by GitHub user w169q169\]*]{.small}

-   Added support for Clang's `--config=` option.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added logging of process exit.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added logging of mtime for files removed from the internal temporary
    directory.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added logging of URLs requested by the http storage backend.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved logging of manifest lookup.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved logging of executed processes.\
    [*\[contributed by Joel Rosdahl with a fix by Leander
    Schulten\]*]{.small}

## Removed features {#_removed_features}

-   Removed support for avoiding the second preprocessor call
    (`run_second_cpp=false`/`CCACHE_NOCPP2`). This feature added
    complexity while offering little practical value, as it was rarely
    used and modern compilers have increasingly poor support for
    compiling preprocessed source code. The maintenance cost therefore
    outweighed the benefit of keeping it.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes_5}

-   Fixed handling of compiler arguments so that ccache now preserves
    their original order, resolving issues where order-sensitive options
    such as `-Werror` could be reordered.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Implemented expansion of system-dependent `-m{arch,cpu,tune}=native`
    options to prevent false cache hits when compiling on different
    hardware.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed rewriting of absolute paths to relative (with `base_dir` in
    effect) so that paths with dereferenced symlinks are no longer
    considered as candidates.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed compiler detection to check Clang before GCC for `cc`/`c++`
    hard links.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed hashing of GCC specs file. Previously specs files located in
    system directories could not be found.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added MSVC variables `INCLUDE` and `EXTERNAL_INCLUDE` to the input
    hash since they affect compilation.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed bad conversion from UTF-16 when reading files on Windows.\
    [*\[contributed by Leander Schulten\]*]{.small}

-   Removed misleading logging of failure to remove output file in hard
    link mode.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_4}

-   Made ccache link statically with libatomic when STATIC_LINK is set.\
    [*\[contributed by Maksym Sobolyev\]*]{.small}

-   Made ccache buildable with tl-expected 1.2.0.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   The bundled copy of libfmt is now used as documented if
    `DEPS=DOWNLOAD`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Switched to use `FetchContent_MakeAvailable` instead of
    `FetchContent_Populate` to avoid warnings with newer CMake
    versions.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Set variables to avoid a warning from downloaded zstd's CMake
    scripts.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added CMake toolchain file for (cross) compilation to
    aarch64-w64-mingw32.\
    [*\[contributed by Martin Storsjö\]*]{.small}

-   Disabled use of BLAKE3 NEON code on big-endian aarch64 since only
    little-endian is supported.\
    [*\[contributed by Jontathan Neuschäfer\]*]{.small}

## Test improvements {#_test_improvements_5}

-   Added test for tricky preprocessed cache hit case.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed calculation of root directory to avoid crashes on some Windows
    systems.\
    [*\[contributed by Leander Schulten\]*]{.small}

## Documentation improvements {#_documentation_improvements_5}

-   Documented that the direct mode has now (since ccache 4.10) less
    risk to read headers from incorrect locations.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Documented that `#pragma once` can be problematic with precompiler
    headers (PCH).\
    \[small\]#*\[contributed by Joel Rosdahl\]*\#

-   Added missing documentation of `"Unsupported source encoding"`
    statistics counter.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.11.3 {#_ccache_4_11_3}

Release date: 2025-05-03

## Bug fixes {#_bug_fixes_6}

-   Fixed handling of Apple Clang `-Xpreprocessor -fopenmp` options
    (regression in ccache 4.10).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_5}

-   Adapted unit test code to compile with doctest 2.4.12.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_6}

-   Silenced benign compiler warning in the profiling_gcc_10+ suite.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.11.2 {#_ccache_4_11_2}

Release date: 2025-03-22

## Bug fixes {#_bug_fixes_7}

-   Reset signal mask and signal defaults when executing compiler. This
    fixes a problem where interrupting the compilation (e.g. with
    Ctrl+C) wouldn't kill the compiler (regression in ccache 4.11).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.11.1 {#_ccache_4_11_1}

Release date: 2025-03-17

## Bug fixes {#_bug_fixes_8}

-   Fixed erroneous log file locking on Windows (regression in ccache
    4.11).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.11 {#_ccache_4_11}

Release date: 2025-03-09

## New features and improvements {#_new_features_and_improvements_3}

-   Added ability to send arbitrary HTTP headers to HTTP storage.\
    [*\[contributed by GitHub user dsrowell\]*]{.small}

-   Added support for MSVC's `/TC` and `/TP` options.\
    [*\[contributed by Huang Qin Jin\]*]{.small}

-   Made the `absolute_paths_in_stderr` feature also handle MSVC
    diagnostics messages.\
    [*\[contributed by Huang Qin Jin\]*]{.small}

-   Absolute paths in MSVC diagnostics messages are now rewritten to
    relative if `base_dir` is in effect.\
    [*\[contributed by Huang Qin Jin\]*]{.small}

-   Added support for NVCC's `--compile` option.\
    [*\[contributed by Laurent Bouhier\]*]{.small}

-   `posix_spawn` is now used instead `execv` to execute the compiler on
    POSIX systems.\
    [*\[contributed by Brendan Shanks\]*]{.small}

-   Added support for GCC's `-fprofile-prefix-path` option.\
    [*\[contributed by Dávid Péter Jánosa\]*]{.small}

-   Added `response_file_format` config option to control response file
    format.\
    [*\[contributed by Max Winkler\]*]{.small}

-   Added support for Clang `-frandomize-layout-seed-file` option.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved `absolute_paths_in_stderr` to recognize more paths
    patterns.\
    [*\[contributed by GitHub user gitmodimo\]*]{.small}

-   Added support for the clang-cl option `/showIncludes:user`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for Intel's LLVM-based compilers `icx` and `icx-cl`.\
    [*\[contributed by Nick Sarnie\]*]{.small}

-   A stat call for `~/.ccache` is now avoided if `CCACHE_DIR` is set.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added Support for `.bat` and `.cmd` scripts as the compiler on
    Windows.\
    [*\[contributed by GitHub user Doekin\]*]{.small}

-   Added support for Clang's `-f{debug,file}-compilation-dir` options.\
    [*\[contributed by Henrique Ferreiro\]*]{.small}

-   Added knowledge about Clang's `--offload-compress` option. This will
    avoid errors when ccache runs the compiler in preprocessor mode.\
    [*\[contributed by Icarus Sparry\]*]{.small}

-   Added knowledge about Clang options `-fmodules-cache-path`,
    `-fmodule-map-file` and `-fbuild-session-file`.\
    [*\[contributed by GitHub user kzlar\]*]{.small}

## Bug fixes {#_bug_fixes_9}

-   Improved handling of paths internally, thereby fixing some issues on
    Windows (for example when using non-ASCII paths).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed interpretation of non-ASCII paths in environment variables on
    Windows.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made sure that remote storage `keep-alive` can be overridden as
    expected.\
    [*\[contributed by GitHub user moha-gh\]*]{.small}

-   Fixed detection of compiler type for hard-linked generic compiler
    name.\
    [*\[contributed by Joel Rosdahl and GitHub user Desour\]*]{.small}

-   Fixed problems with matching a path with `base_dir` if either ends
    with a slash.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   The `-fprofile-abs-path` option is now correctly passed through to
    GCC.\
    [*\[contributed by Matt Johnston\]*]{.small}

-   Writes to the log file are now synchronized.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Command line config options ending with "/ccache" are now handled
    properly.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made `--trim-method mtime` actually use mtime instead of atime.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed a bug where ccache failed to rename raw files correctly for
    large caches that have more than two cache levels.\
    [*\[contributed by Oded Shimon\]*]{.small}

## Build improvements {#_build_improvements_6}

-   Instructed MSVC to accept UTF-8 characters in ccache's own source
    code.\
    [*\[contributed by Huang Qin Jin\]*]{.small}

-   Fixed binary patching of `sysconfdir` for the prebuilt Linux
    binary.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added an `HTTP_STORAGE_BACKEND` build option to make it possible to
    turn off the http storage backend.\
    [*\[contributed by Maksym Sobolyev\]*]{.small}

-   Fixed call to `sha256sum` on macOS.\
    [*\[contributed by Henrique Ferreiro\]*]{.small}

## Test improvements {#_test_improvements_7}

-   Made tests pass in year 2038.\
    [*\[contributed by Bernhard M. Wiedemann\]*]{.small}

-   Refreshed some Dockerfiles.\
    [*\[contributed by Maksym Sobolyev\]*]{.small}

## Documentation improvements {#_documentation_improvements_6}

-   Added documentation saying that `absolute_paths_in_stderr` also
    applies to stdout.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed description of `default cache_dir` on non-macOS POSIX
    systems.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Clarified how ccache's LRU cleanup works.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.10.2 {#_ccache_4_10_2}

Release date: 2024-07-22

## Build improvements {#_build_improvements_7}

-   Fixed detection of Fmt version 11 and newer.\
    [*\[contributed by Holger Hoffstätte and Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_8}

-   Made the "-fprofile-update=atomic" test only run when that option is
    supported by the compiler.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made the color diagnostics tests work when the user running the
    tests has a non-POSIX login shell.\
    [*\[contributed by Anders F Björklund\]*]{.small}

# Ccache 4.10.1 {#_ccache_4_10_1}

Release date: 2024-06-30

## Bug fixes {#_bug_fixes_10}

-   Fixed prefix command lookup from `PATH`.\
    [*\[contributed by Romain Geissler\]*]{.small}

## Build improvements {#_build_improvements_8}

-   Fixed detection and usage of system blake3.\
    [*\[contributed by Carlo Cabrera\]*]{.small}

-   Find CppHttplib named libhttplib.so as well.\
    [*\[contributed by Sam James\]*]{.small}

-   Removed Xcode assembly workaround for zstd.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Added bundled subset of Fmt again for convenience.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Removed no longer needed workaround when building downloaded Zstd.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_7}

-   Clarified that `--set-config` writes to the configuration file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.10 {#_ccache_4_10}

Release date: 2024-05-29

## New features and improvements {#_new_features_and_improvements_4}

-   Added support for GCC option `-fcallgraph-info`.\
    [*\[contributed by Raihaan Shouhell\]*]{.small}

-   Added support for GCC option `-fprofile-update`.\
    [*\[contributed by Raihaan Shouhell\]*]{.small}

-   Added support for GCC option `-fdump-ipa-clones`.\
    [*\[contributed by Jiri Slaby\]*]{.small}

-   Added support for the MSVC `/Yc` option (precompiled header).\
    [*\[contributed by Clemens Wasser, Thomas Ferrand and Silver
    Zachara\]*]{.small}

-   Added support for the MSVC `/Tc<path>` and `/Tp<path>` options
    (specifying source code type).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added an experimental inode cache implementation for Windows. This
    speeds up ccache a lot when many headers are included, both for
    cache hits and cache misses.

    ::: note
    This feature is currently disabled by default, but interested
    Windows users are encouraged to try it out by setting [*inode_cache
    = true*](https://ccache.dev/manual/4.10.html#config_inode_cache).
    :::

    [*\[contributed by Thomas Ferrand\]*]{.small}

-   Added knowledge of Xcode option `-ivfsstatcache`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for Apple Clang option `-Xpreprocessor -fopenmp` in
    direct mode.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added knowledge of Emscripten option `--em-config`.\
    [*\[contributed by Byoungchan Lee\]*]{.small}

-   Reduced the risk of false positive direct mode hits.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Clear direct mode manifest on recache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Optimized file reading on Windows.\
    [*\[contributed by Clemens Wasser\]*]{.small}

-   Optimized file copying performed when [hard
    linking](https://ccache.dev/manual/4.10.html#config_hard_link) or
    [file cloning](https://ccache.dev/manual/4.9.html#config_file_clone)
    is enabled.\
    [*\[contributed by Raihaan Shouhell\]*]{.small}

-   Use `posix_spawn(3)` for executing compiler check commands.\
    [*\[contributed by Brendan Shanks\]*]{.small}

-   The
    [*prefix_command*](https://ccache.dev/manual/4.10.html#config_prefix_command)
    and
    [*prefix_command_cpp*](https://ccache.dev/manual/4.10.html#config_prefix_command_cpp)
    configuration options now allow any prefix, not only programs that
    exist in `PATH`. This means that *prefix_command* now can be a
    program with arguments.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added a new `incbin`
    [*sloppiness*](https://ccache.dev/manual/4.10.html#config_sloppiness)
    value for ignoring presence of `.incbin` directives in the source
    code.\
    [*\[contributed by Raihaan Shouhell\]*]{.small}

-   Added a `--print-log-stats` option that prints a machine-parsable
    variant of `--show-log-stats`.\
    [*\[contributed Kaspar Schleiser\]*]{.small}

-   Added a `--format` option for selecting JSON or tab format for
    `--print-stats` and `--print-log-stats`.\
    [*\[contributed Kaspar Schleiser\]*]{.small}

-   Added a `--print-version` option for printing ccache version in
    machine-parsable format.\
    [*\[contributed by Silver Zachara\]*]{.small}

-   The `--inspect` option now retains access time (atime) of the
    inspected file if possible.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes_11}

-   Fixed reading of files larger than 2^31^ bytes on some systems where
    this was a problem.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved handling of large files on 32-bit systems.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Nonexistent include files are allowed in preprocessor mode again,
    fixing regression in ccache 4.9.1.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   The Clang `-fdiagnostics-color` option is now handled again, fixing
    regression in ccache 4.6.2.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed assertion failure on Windows mapped network drives.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed handling of MSVC options `/Fp` and `/Yu`.\
    [*\[contributed by Silver Zachara\]*]{.small}

-   Fixed lock file implementation on MSYS2.\
    [*\[contributed by GitHub user Kreijstal\]*]{.small}

-   The "apparent real path" of the object file is now added to the
    input hash when using `-fprofile-arcs` to avoid false positive hits
    in some scenarios.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   When generating profiling information,
    [*run_second_cpp*](https://ccache.dev/manual/4.10.html#config_) is
    now forced to true so that the coverage report won't refer to a
    temporary preprocessed file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_9}

-   Improved handling of ccache dependencies. A new `DEPS` CMake
    variable selects how software library dependencies should be located
    or retrieved, replacing the old `HIREDIS_FROM_INTERNET`,
    `ZSTD_FROM_INTERNET` and `OFFLINE` variables. Options are `AUTO`
    (the default) for automatically downloading missing dependencies,
    `DOWNLOAD` for always downloading and `LOCAL` for never downloading.
    See [*Software library
    dependencies*](https://github.com/ccache/ccache/blob/v4.10/doc/INSTALL.md#software-library-dependencies)
    for details.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for using a local installation of BLAKE3, cpp-httplib,
    nonstd-span and tl-expected instead of linking to bundled copies.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Removed bundled copies of doctest, fmt, getopt_long and xxhash.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Changed to use the Windows BLAKE3 implementation when building on
    MSYS2.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_8}

-   Improved documentation of "gcno_cwd sloppiness".\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.9.1 {#_ccache_4_9_1}

Release date: 2024-02-05

## Bug fixes {#_bug_fixes_12}

-   Improved detection of bad remote storage URLs gracefully. This also
    fixes crashes seen in ccache's own test suite.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made caching completely disabled when modification of a source or
    include file is detected during ccache invocation. Previously this
    was only done for the direct mode.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed an MSVC crash when using `/Zi` with many concurrent
    compilations.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed a crash when `-arch` is the last compiler option.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.9 {#_ccache_4_9}

Release date: 2023-12-30

## New features and improvements {#_new_features_and_improvements_5}

-   Made `ignore_options`/`CCACHE_IGNOREOPTIONS` also skip the option
    from special processing, similar to how `--ccache-skip` works.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for expanding environment variables references in all
    configuration options.\
    [*\[contributed by GitHub user cupu\]*]{.small}

-   MSVC options `/Fd`, `/FS` and `/MP` are no longer included in the
    input hash.\
    [*\[contributed by Huang Qin Jin\]*]{.small}

-   Made ccache terminate an ongoing compiler subprocess when terminated
    on all platforms, not only on Unix.\
    [*\[contributed by Andreas Reischuck\]*]{.small}

-   Added support for multiple `-Xarch_*` arguments matching `-arch`.\
    [*\[contributed by Tadej Novak\]*]{.small}

-   Added a `debug_level`/`CCACHE_DEBUGLEVEL` configuration option,
    making it possible to tell ccache to only write a log file for each
    compilation, not other debug files.\
    [*\[contributed by GitHub user dsilakov\]*]{.small}

-   Added `max_cache_size_kibibyte` and `max_files_in_cache` fields in
    output from `ccache --print-stats`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Paths after `-Xclang -include` are now rewritten to relative paths
    if `base_dir`/`CCACHE_BASEDIR` is in effect.\
    [*\[contributed by Jiulong Wang\]*]{.small}

-   Added support for `clang --analyze`.\
    [*\[contributed by GitHub user mbel\]*]{.small}

-   Improved processing of input file arguments.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for `st_Xtimensec` fields in `struct stat`, thus
    improving behavior on some BSDs when using newly created include
    files.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for the undocumented GCC/Clang option `--include`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes_13}

-   Ccache now exits more gracefully on invalid sharded remote storage
    URLs.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made ccache bail out on too hard options `-fmodules-ts`,
    `-fmodule-header`, `-wrapper` and `-Xclang -ast-dump`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Stopped relying on the `st_blocks` field in `struct stat` since it
    cannot be trusted for filesystems such as ZFS that do transparent
    compression or deduplication and adjust `st_blocks` some time in the
    future.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed crash on Windows for paths with only a drive letter.\
    [*\[contributed by Martin Blanchard\]*]{.small}

-   Made handling of Clang config options (such as
    `--config-system-dir`) more robust.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed compiler type detection when compiler is a symlink called
    "clang-cl".\
    [*\[contributed by GitHub user DarkShadow44\]*]{.small}

-   Made sure to use MSVC logic for `clang-cl` when handling a
    precompiled header.\
    [*\[contributed by GitHub user DarkShadow44\]*]{.small}

-   Generalized expansion of remote storage URLs with sharding, for
    instance making it possible to shard on port number.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_10}

-   Upgraded to xxHash 0.8.2, thereby fixing an error when compiling
    ccache with `-Og`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed sign-compare warning in `src/InodeCache.cpp` on FreeBSD.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed the CMake option `STATIC_LINK` on Linux/macOS.\
    [*\[contributed by Rafael Kitover\]*]{.small}

-   Added the CMake option `OFFLINE`, defaulting to the value of the
    standard variable `FETCHCONTENT_FULLY_DISCONNECTED` (which is OFF by
    default), to disable downloading anything from the internet.\
    [*\[contributed by Rafael Kitover\]*]{.small}

-   Fixed warnings about unused functions on new MSVC versions.\
    [*\[contributed by Rafael Kitover\]*]{.small}

-   Made sure to set both C and C++ CMake compiler launcher variables if
    either is set.\
    [*\[contributed by Rafael Kitover\]*]{.small}

## Documentation improvements {#_documentation_improvements_9}

-   The manual now mentions that `system_headers` sloppiness is not
    supported for MSVC.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_9}

-   Fixed regex in direct.bash.\
    [*\[contributed by Viktor Szépe\]*]{.small}

## Other improvements {#_other_improvements}

-   Remove duplicated call to `posix_spawn_file_actions_init`.\
    [*\[contributed by Juan Manuel Martinez Caamaño\]*]{.small}

# Ccache 4.8.3 {#_ccache_4_8_3}

Release date: 2023-08-29

## Bug fixes {#_bug_fixes_14}

-   Fixed various problems with parsing of MSVC response file (`.rsp`).\
    [*\[contributed by Jiri Hörner\]*]{.small}

-   Fixed handling of NVCC `-Xcompiler` and `--Werror` options.\
    [*\[contributed by Andrew Hardin\]*]{.small}

-   Fixed bookkeeping of files when hard linking or file cloning is
    enabled. In ccache 4.8--4.8.2 this could result in incorrect
    size/count statistics after automatic or explicit cleanup.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_11}

-   Made a workaround for GCC 12.3 bug 109241 where GCC fails to compile
    ccache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Upgraded to xxHash 0.8.2, which fixes compilation of ccache with GCC
    12 and `-Og`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.8.2 {#_ccache_4_8_2}

Release date: 2023-06-12

## Bug fixes {#_bug_fixes_15}

-   Fixed parsing of Windows drive letter in file URLs for remote
    storage.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed a bug affecting depend mode with MSVC.\
    [*\[contributed by Huang Qin Jin\]*]{.small}

-   Ccache no longer passes `-v` to the preprocessor. This improves
    preprocessor mode hit rate when `-v` is on the compiler command
    line.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made `--trim-max-size` accept 0 for no limit.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_12}

-   Made various fixes for Windows 64-bit MSBuild builds.\
    [*\[contributed by Rafael Kitover\]*]{.small}

-   Silenced CMake warning for extracted timestamps.\
    [*\[contributed by Rafael Kitover\]*]{.small}

-   Worked around problem with building ZStandard with Xcode.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Fixed undefined behavior (only triggered by unit tests) in
    `util::read_file_part` for zero count, making the build fail with
    `_GLIBCXX_ASSERTIONS`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_10}

-   Clarified `--evict-older-than` semantics.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_10}

-   Fixed typo in "Directory is not hashed if using -gz" test.\
    [*\[contributed by Sam James\]*]{.small}

# Ccache 4.8.1 {#_ccache_4_8_1}

Release date: 2023-05-19

## Bug fixes {#_bug_fixes_16}

-   Fixed an issue with the depend mode in combination with `--` on the
    command line for Clang-based compilers.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved knowledge about MSVC debug flags so that non-debug `/Z*`
    options are once again supported.\
    [*\[contributed by Stephan Rohmen\]*]{.small}

-   Ccache no longer treats `/Zi` as unsupported for clang-cl.\
    [*\[contributed by Tobias Hieta\]*]{.small}

-   Made the output format of `ccache -k max_size` parsable by ccache
    itself.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build/CI improvements {#_buildci_improvements}

-   Corrected ccache version in the macOS binary release.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made it possible to build ccache with clang-cl on Windows.\
    [*\[contributed by Tobias Hieta\]*]{.small}

-   Upgraded to doctest 2.4.11, thereby fixing a build issue on
    Solaris.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_11}

-   Added a remote file storage example with URL-encoded spaces.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.8 {#_ccache_4_8}

Release date: 2023-03-12

## New features and improvements {#_new_features_and_improvements_6}

-   Improved the automatic cache cleanup mechanism. Automatic cleanups
    are now performed on 1/256 of the cache instead of 1/16, thus making
    them much quicker (but naturally more frequent). Cleanups are
    coordinated between ccache processes so that at most one process
    will perform cleanup at a time. Also, the actual cache size will
    stay very close to the configured maximum size instead of staying
    around 90% as was the case before.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for setting per-compilation configuration options on
    the command line. Example:
    `ccache hash_dir=false gcc -c example.c`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made it possible to disable ccache for a certain source code file by
    embedding the string `ccache:disable` in a comment near the top of
    the file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made ccache understand that an MSVC `/Z7` option overrides an
    earlier `/Z*` option and thus is not too hard to cache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added a `--recompress-threads` command line option for selecting the
    number of CPU threads to use when recompressing the local cache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added `--trim-recompress` and `--trim-recompress-threads` command
    line options for recompressing file-based remote storage.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added tmpfs, ufs and zfs to the list of supported filesystems on
    macOS and BSDs for the inode cache.\
    [*\[contributed by Oleg Sidorkin\]*]{.small}

-   Improved progress bars for clean/clear/evict-style operations.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved printing of cache sizes in various outputs.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Activate debug logging for command mode options like `--cleanup`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for `-Wp,-U<macro>` in the direct mode.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added quotes around arguments with space in logged command lines.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added logging of executed command lines on Windows.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made sure not to update the stats file when there are no incremented
    counters.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved actual disk size calculation on Windows.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build/CI improvements {#_buildci_improvements_2}

-   Added CI support for building macOS universal binaries.\
    [*\[contributed by Raihaan Shouhell\]*]{.small}

-   Make it possible to force download of Zstd and Hiredis, e.g. with
    `cmake -D ZSTD_FROM_INTERNET=ON […​]`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes_17}

-   Fixed an edge case where a non-temporal identifier is
    misidentified.\
    [*\[contributed by Erik Flodin\]*]{.small}

-   Fixed reporting of local/remote cache misses in depend mode.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed parsing of backslashes in MSVC RSP files.\
    [*\[contributed by Raihaan Shouhell\]*]{.small}

-   Fixed a crash in `--show-log-stats` when the stats log file doesn't
    exist.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed matching of base directory for MSVC. The base directory will
    now match case-insensitively with absolute paths in preprocessed
    output, or from `/showIncludes` in the depend mode case, when
    compiling with MSVC.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed a problem where the original umask would be used when storing
    a remote cache result in the local cache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Changed the inode cache implementation to use spinlocks instead of
    pthread mutexes. This makes the inode cache work on FreeBSD and
    similar systems.\
    [*\[contributed by Oleg Sidorkin\]*]{.small}

-   Don't treat `-Wp,-D` as interchangeable with `-D`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Disable the inode cache if the filesystem risks getting full soon.
    This fixes a problem when the cache is on a filesystem where
    `posix_fallocate` isn't reliable, like Btrfs with compression
    enabled.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed performance of cache path relativization in preprocessed
    output, primarily on Windows where `stat` calls are relatively
    costly.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed rare crash in the signal handler at process exit.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed handling of Unix-style paths passed to MSVC.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed so that the config options and command line are logged before
    trying to locate the compiler and exiting early.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_12}

-   Improved description of `--set-config`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed broken markup in the manual.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added a note to the manual that `stats = false` will disable
    automatic cleanup.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fix a bad reference to the "Remote storage backends" section.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.7.5 {#_ccache_4_7_5}

Release date: 2023-03-20

## Bug fixes {#_bug_fixes_18}

-   Disabled the inode cache by default again since there have reports
    of ccache processes hanging on futex calls related to the inode
    cache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.7.4 {#_ccache_4_7_4}

Release date: 2022-11-21

## Bug fixes {#_bug_fixes_19}

-   Fixed an inode cache race condition.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   The default temporary directory is now `$XDG_RUNTIME_DIR/ccache-tmp`
    instead of a hardcoded `/run/user/<UID>/ccache-tmp`. If
    `XDG_RUNTIME_DIR` is not set, `<cache_dir>/tmp` is used. This avoids
    creating `/run/user/<UID>` on systems that don't have it if
    compiling as root.\
    [*\[contributed by Joel Rosdahl and Oleg Sidorkin\]*]{.small}

-   Added a fallback in case `posix_fallocate` returns `EINVAL` when
    creating the inode cache file.\
    [*\[contributed by Oleg Sidorkin\]*]{.small}

-   Connection timeout for an HTTP connection is now reported as a
    timeout instead of an error.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Temporary files found in the cache are no longer counted in
    `--show-compression`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Removed duplicate magic header in output from `--inspect`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Ccache now properly waits for all recompression jobs to finish when
    there is no `f` subdirectory in the cache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Other minor improvements {#_other_minor_improvements}

-   Improved inode cache logging.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_13}

-   Removed stray parenthesis.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved description of how header files are handled.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added a hint about using `-fno-pch-timestamp` for precompiled
    headers with Clang.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Removed obsolete description of compiler type "pump".\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.7.3 {#_ccache_4_7_3}

Release date: 2022-11-05

## New features and improvements {#_new_features_and_improvements_7}

-   Re-added support for handling a `-Wp,-MD` or `-Wp,-MMD` option with
    `-o` but without `-MMD`, `-MQ` or `-MT` for GCC and Clang. (This
    combination of options is used by the Linux kernel build system and
    became unsupported as a side-effect of a feature added in ccache
    4.7.)\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Variables that affect Clang version on macOS are now added to the
    input hash.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Variables that affect the underlying compiler used by ICC (the Intel
    compiler) are now added to the input hash.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes_20}

-   Fixed parsing of sloppiness with a trailing delimiter.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Other minor improvements {#_other_minor_improvements_2}

-   Removed a redundant slash in URLs when querying remote HTTP
    storage.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved logging related to the inode cache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_14}

-   Added documentation of the default value of **keep_comments_cpp**.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_11}

-   Silenced various benign test warnings.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.7.2 {#_ccache_4_7_2}

Release date: 2022-10-29

## Bug fixes {#_bug_fixes_21}

-   Fixed a problem when using 32-bit and 64-bit ccache binaries with
    the same inode cache file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Ccache now processes the argument following a `-Xarch` option.\
    [*\[contributed by Keith Buck\]*]{.small}

-   Made sure to use the configured umask for command line operations
    like `--zero-stats` so that newly created cache directories will
    have correct permissions.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_13}

-   Include `limits.h` for `PATH_MAX`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_12}

-   Disabled flaky Windows profiling tests.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.7.1 {#_ccache_4_7_1}

Release date: 2022-10-22

## Bug fixes {#_bug_fixes_22}

-   Fixed a regression in 4.7 related to using the `-MD` or `-MMD`
    option when compiling an assembler file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_14}

-   Added support for compiling ccache with GCC 8.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

-   Removed unneeded C++11 flag in libatomic test.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

# Ccache 4.7 {#_ccache_4_7}

Release date: 2022-10-17

## Compatibility notes {#_compatibility_notes}

-   The cache entry format has changed, so ccache 4.7 will not share
    cache entries with earlier versions. Different ccache versions can
    however still use the same cache storage without any issues.

-   The [default location of the cache
    directory](https://ccache.dev/manual/4.7.html#config_cache_dir) on
    Windows has been changed from `%APPDATA%\ccache` to
    `%LOCALAPPDATA%\ccache`. Please remove any existing
    `%APPDATA%\ccache` directory or move it to `%LOCALAPPDATA%\ccache`
    to keep it.

## Changed tooling {#_changed_tooling}

-   A C++17 compiler and CMake 3.15 or newer are now required to build
    ccache.

## New and improved features {#_new_and_improved_features}

-   The [inode
    cache](https://ccache.dev/manual/4.7.html#config_inode_cache) is now
    enabled by default, but only if the filesystem where ccache's
    temporary directory is located is known to work with the inode
    cache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved performance of cache entry reading and writing.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added a
    [**remote_only**](https://ccache.dev/manual/4.7.html#config_remote_only)
    configuration option, which tells ccache to disable local storage.
    This way, ccache can use a shared [network
    cache](https://ccache.dev/manual/4.7.html#_remote_storage_backends)
    without writing cache entries locally, which can be useful if the
    local storage is ephemeral.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Renamed configuration option **secondary_storage** to
    [**remote_storage**](https://ccache.dev/manual/4.7.html#config_remote_storage).
    The old spelling will still work as a deprecated alias.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved handling of manifests when using both local and remote
    storage.

    On a cache miss, ccache used to update the local manifest file and
    write it to remote storage, thereby overwriting any preexisting
    manifest entries on remote storage. Similarly, the local manifest
    could be replaced by the remote manifest on a remote cache hit, thus
    discarding local entries. This has now been improved so that ccache
    will merge local and remote manifest entries transparently.\
    [*\[contributed by Joel Rosdahl and GitHub user bengtj\]*]{.small}

-   Added support for caching assembler listing files with compiler
    option `-Wa,-a=file`. This also fixes a bug in ccache 4.6.2+ where
    usage of `-Wa,-march=…​` makes ccache fall back to running the
    compiler.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved statistics shown by `ccache --show-stats`. Most values are
    now shown in relation to a total count, and some less useful
    statistics counters have been changed to be displayed only with
    `--verbose`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved statistics for remote hits and misses.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Renamed "Primary config" to "Config file" and "Secondary config" to
    "System config file" in the output of
    `ccache --show-stats --verbose`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for [masquerading as a
    compiler](https://ccache.dev/manual/4.7.html#_run_modes) via a copy
    or hard link of the ccache executable. Previously, ccache only
    supported masquerading as a compiler by using a symbolic link.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   A timestamp is now included in [per-object debug
    filenames](https://ccache.dev/manual/4.7.html#_cache_debugging).
    This makes it easier to compare two builds without having to save
    previous debug files before the second build. It also makes sure
    debug files won't be overwritten if an object file is compiled
    several times during one build.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for Clang's `--` option.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Cache entries are now shared for different `-MT`/`-MQ` options.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   The [default location of the cache
    directory](https://ccache.dev/manual/4.7.html#config_cache_dir) on
    Windows has been changed to `%LOCALAPPDATA%\ccache`, both in Windows
    Bash and Windows native environments such as CMD or Powershell.

    Previous ccache versions defaulted to storing the cache in
    `%APPDATA%\ccache` on Windows in native environment (i.e., when the
    `%USER%` variable was not set), which could result in large network
    file transfers of the cache in domain environments and similar
    problems.\
    [*\[contributed by Rafael Kitover\]*]{.small}

-   Ccache now uses subsecond resolution timestamps when checking for
    "too new include files". In practice, this means that the direct
    mode will no longer be disabled for newly generated include files.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Started using subsecond resolution timestamps in manifest files.
    This improves accuracy with **file_stat_matches**
    [sloppiness](https://ccache.dev/manual/4.7.html#config_sloppiness).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for subsecond timestamps on macOS.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added [depend
    mode](https://ccache.dev/manual/4.7.html#_the_depend_mode) support
    for MSVC.\
    [*\[contributed by Orgad Shaneh and Luboš Luňák\]*]{.small}

-   Added support for the Intel compiler on Windows.\
    [*\[contributed by Daniel Richtmann\]*]{.small}

-   Ccache now sets `CCACHE_DISABLE` when running the compiler. This
    avoids running ccache twice (and potentially storing two different
    results in the cache) if, for instance, the compiler happens to be a
    wrapper script that in turn runs `ccache $compiler …​`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for Redis over Unix sockets.\
    [*\[contributed by Anders F Björklund\]*]{.small}

-   Added support for GCC's `-fprofile-abs-path` option by including the
    current working directory in the input hash. To opt out of this, set
    **gcno_cwd**
    [sloppiness](https://ccache.dev/manual/4.7.html#config_sloppiness).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made it possible to exclude `-frandom-seed=seed` options from the
    input hash with a new **random_seed**
    [sloppiness](https://ccache.dev/manual/4.7.html#config_sloppiness).\
    [*\[contributed by Raihaan Shouhell\]*]{.small}

-   Added support for server name in [remote storage file
    URLs](https://ccache.dev/manual/4.7.html#_file_storage_backend) on
    Windows.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Configuration file locations are now included in the [debug
    log](https://ccache.dev/manual/4.7.html#_cache_debugging).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   The inode cache file is no longer removed with `ccache --clear`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Result format version and number of files are now printed when
    inspecting a result cache entry file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Removed features {#_removed_features_2}

-   Removed the **share-hits** attribute for remote storage. It has been
    superseded by the
    [**remote_only**](https://ccache.dev/manual/4.7.html#config_remote_only)
    configuration option.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Buggy support for GCC-specific environment variables
    `DEPENDENCIES_OUTPUT` and `SUNPRO_DEPENDENCIES` has been removed. If
    any of those variables are set, ccache now just falls back to
    running the real compiler.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes_23}

-   The correct dependency target will now be produced even when a [base
    directory](https://ccache.dev/manual/4.7.html#config_base_dir) is
    used --- the dependency target will still be an absolute path.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed a bug that could lead to bad modification timestamp (mtime)
    for object files on systems that lack `utimensat` and `utimes`
    system calls (such as Windows).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed ordering of MSVC include directory options when using
    `/external:I<directory>`.\
    [*\[contributed by Raihaan Shouhell\]*]{.small}

-   Fixed capturing of MSVC stdout/stderr when running from Visual
    Studio.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

-   Carriage return characters are now retained in the compiler output
    on Windows.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

-   Made sure not to increment the "preprocessed_cache_miss" counter in
    recache mode.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed an issue with the inode cache in combination with
    `__DATE__`/`__TIME__`/`__TIMESTAMP__` macros in the source code.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made sure to enable the inode cache only if subsecond timestamps are
    available.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Cache entries created with enabled hard linking or file cloning are
    no longer written to remote storage since they won't be possible to
    retrieve correctly anyway.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Ccache now accepts spaces between target and colon when parsing
    dependency files in the depend mode.\
    [*\[contributed by Louis Caron\]*]{.small}

-   Fixed a crash when failing to write an error message to stderr after
    failing to write to the log file.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made ccache able to retrieve an object file from the cache even if
    the destination object file exists and is read-only.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   The `.exe` extension is now stripped from the ccache executable name
    in `ccache --version` on Windows.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

-   Fixed naming of temporary files written to the cache directory.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_15}

-   Enabled static runtime linking for MSVC.\
    [*\[contributed by Cristian Adam and Rafael Kitover\]*]{.small}

-   The Zstandard and Hiredis dependencies are now by default downloaded
    from the Internet when unavailable.\
    [*\[contributed by Rafael Kitover\]*]{.small}

-   Added support for pkgconfig to find a Zstandard installation.\
    [*\[contributed by Rosen Penev\]*]{.small}

-   Removed usage of the deprecated `codecvt` header.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

-   Added headers to CMake project files.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

## Test improvements {#_test_improvements_13}

-   Made the integration tests work on Windows.\
    [*\[contributed by Orgad Shaneh and R. Voggenauer\]*]{.small}

-   Improved diagnostics from the "Version output readable" test.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

-   Made setting the `KEEP_TESTDIR` variable actually work.\
    [*\[contributed by Louis Caron\]*]{.small}

-   Fixed a typo in depend mode tests.\
    [*\[contributed by Louis Caron\]*]{.small}

-   Added more depend mode tests.\
    [*\[contributed by Louis Caron\]*]{.small}

## Documentation improvements {#_documentation_improvements_15}

-   Improved the [installation
    guide](https://github.com/ccache/ccache/blob/v4.7/doc/INSTALL.md).\
    [*\[contributed by Rafael Kitover\]*]{.small}

-   Fixed a typo in the help text.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.6.3 {#_ccache_4_6_3}

Release date: 2022-08-27

## Bug fixes {#_bug_fixes_24}

-   Fixed MSVC support (regression in ccache 4.6.2).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed detection of PCH header for concatenated `-include` option
    (e.g., `-includepch.h` instead of `-include pch.h`).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_16}

-   Fixed build with musl when using GCC 12.\
    [*\[contributed by Khem Raj\]*]{.small}

## Test improvements {#_test_improvements_14}

-   Disabled the "Failure to write output file" test when running on a
    filesystem that doesn't support read-only directories.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.6.2 {#_ccache_4_6_2}

Release date: 2022-08-22

## Bug fixes {#_bug_fixes_25}

-   Fixed a race condition that could lead to a crash if a file in the
    cache is removed with unlucky timing, e.g. by another ccache process
    doing cache cleanup.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Dependency file rewriting will now always be performed if
    `base_dir`/`CCACHE_BASEDIR` is active. This fixes a problem with the
    dependency file content when Clang is used with
    `-fsanitize=address`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed handling of error condition for
    `--hash-file`/`--checksum-file`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made sure to enable the inode cache only if subsecond `stat`
    timestamps are available.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added a work-around for a Clang bug when writing to a full NFS file
    system.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made failure writing to the output file increment the "bad output
    file" counter instead of "cache miss".\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed false positive cache hits for code constructions similar to
    `asm(".incbin" " \"file\"")`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed false success for `-fcolor-diagnostics` probe with GCC. A side
    effect of this is that a compiler type that ccache can't identify
    from the compiler name (such as `/usr/bin/cc` where `cc` is not a
    symlink) from now on won't produce color diagnostics when used via
    ccache even if the compiler actually is GCC or Clang.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   More cases of invalid secondary storage URLs are now handled
    gracefully.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed the display of maximum cache size in `ccache -s` if it's 0 (=
    unlimited).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Removed AsciiDoc markup from help text of `--trim-dir`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   The temporary directory is now cleaned up properly even if it's left
    unconfigured.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made cleanup of the temporary directory not rely a directory
    timestamp.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made sure to retain mtime/atime when recompressing cache files with
    `-X`/`--recompress`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   The correct umask is now used when populating the primary cache from
    a secondary cache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed creation of temporary files on file systems that don't support
    hard links (such as FAT32).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added knowledge about `-Wa,…​=file` so that ccache then falls back to
    running the real compiler.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Corrected handling of space in paths when using response file on
    Windows.\
    [*\[contributed by Sergey Semushin\]*]{.small}

-   Fixed crash due to empty include filename in preprocessor output
    generated by `f2c`.\
    [*\[contributed by Oleg Sidorkin\]*]{.small}

## Build improvements {#_build_improvements_17}

-   Fixed build problems with a development version of GCC 13.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed build problems with MSVC.\
    [*\[contributed by Florin Trofin\]*]{.small}

## Test improvements {#_test_improvements_15}

-   Clang warnings from the "-fdebug-prefix-map" test are now
    suppressed.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made sure to only run the "-ftest-coverage + -fprofile-dir" test
    with GCC.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed printing of error messages with embedded newlines.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed warning when running the "inode_cache" test in isolation.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed test failure when the compiler used for testing is an old
    ccache version masquerading as the compiler.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_16}

-   Mentioned that mtime is used for LRU cleanup.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.6.1 {#_ccache_4_6_1}

Release date: 2022-05-15

## New features {#_new_features}

-   Added support for passing a directory to the MSVC `/Fo` option.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

-   Added knowledge about the `-imsvc` compiler option.\
    [*\[contributed by Jacob Young\]*]{.small}

-   Added knowledge about the `-z` linker option.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes_26}

-   Improved handling of `.gcno` files in combination with absolute
    input file paths.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Adapted to changes in GCC 9+ `.gcno` files, which contain the
    current working directory, by including said directory in the hash.
    You can opt out of this by enabling "gcno_cwd sloppiness".\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   A preexisting object file is no longer considered when using
    `-fsyntax-only`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Authenticate with Redis before database selection.\
    [*\[contributed by GitHub user 6d5CfLQ3dYAb\]*]{.small}

-   Don't exit with an error on failure reading a cached file.\
    [*\[contributed by GitHub user 6d5CfLQ3dYAb\]*]{.small}

-   Bail out on too hard MSVC environment variables `CL` and `_CL_`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Only use `/run/user/<UID>/ccache-tmp` as the temporary directory if
    it's writable.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed handling of the final newline in cached standard output from
    the compiler.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

-   Fixed a bug related to distcc markers in standard error output.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Paths to `base_dir` are now properly normalized on Windows.\
    [*\[contributed by Vili Väinölä and Joel Rosdahl\]*]{.small}

-   Fixed handling of MSVC `/Fp` and `/Yu` options with concatenated
    path.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed "Multiple precompiled headers used" error if MSVC `/Yu` option
    is used after `/Fp`.\
    [*\[contributed by Alexey Telishev\]*]{.small}

-   Check for short reads when reading strings in result/manifest
    files.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Log expanded secondary storage URL in put/remove.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed logging of statistics counters with value higher than one in
    debug log and stats log.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Avoid incorrect error log message for Redis write operations in
    `reshare` mode.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Support Redis URL without host (meaning localhost).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Build improvements {#_build_improvements_18}

-   Prefer CMake find module for hiredis and zstd packages.\
    [*\[contributed by Cristian Adam and Joel Rosdahl\]*]{.small}

-   Fixed building and linking BLAKE3 with MSVC.\
    [*\[contributed by Rafael Kitover\]*]{.small}

-   Fixed static linkage with hiredis on Windows.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

-   Fixed miscompile of nonstd::expected on MSVC v19.22.\
    [*\[contributed by Jacob Young\]*]{.small}

-   Fixed build arguments to clang-cl.\
    [*\[contributed by Jacob Young\]*]{.small}

-   Fixed parsing of MSVC response files.\
    [*\[contributed by Jacob Young\]*]{.small}

-   Support Git 1.x when determining ccache version.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_16}

-   Worked around an endianness problem which affected builds and tests
    on big-endian systems.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   A C++-capable compiler is no longer required for the test suite.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed an issue with inode cache tests, leading to sporadic failures
    in the inode test suite when running many parallel tests.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed sporadic failures in the profiling test suite.\
    [*\[contributed by Jacob Young\]*]{.small}

## Documentation improvements {#_documentation_improvements_17}

-   Added reference to example build configs in installation
    instructions.\
    [*\[contributed by GitHub user vsplesk/\]*]{.small}

-   Default cache locations are now mentioned for Windows and macOS as
    well.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added a warning about usage of `base_dir`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.6 {#_ccache_4_6}

Release date: 2022-02-27

## New features {#_new_features_2}

-   Added support for caching calls to Microsoft Visual C++ (MSVC) and
    clang-cl (MSVC compatibility for Clang).\
    [*\[contributed by Cristian Adam, Luboš Luňák, Orgad Shaneh and Joel
    Rosdahl\]*]{.small}

-   Added an option to use a bearer token with the HTTP backend. This
    makes it possible to use e.g. Google Cloud Storage as a secondary
    storage backend.\
    [*\[contributed by GitHub user Delgan\]*]{.small}

-   Added support for caching standard output from the compiler.\
    [*\[contributed by Luboš Luňák and Joel Rosdahl\]*]{.small}

-   Added a new `--inspect` option for debugging cache entries,
    replacing the previous `--dump-manifest` and `--dump-result`
    options.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Enabled HTTP keep-alive by default.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes_27}

-   Fixed copying of binary files on Windows.\
    [*\[contributed by R. Voggenauer\]*]{.small}

-   Improved detection of the `.incbin` assembler directive to reduce
    false positives.\
    [*\[contributed by Alexey Sheplyakov\]*]{.small}

-   Ccache now verifies that `/run/user/<UID>/ccache-tmp` is writable
    before using it for temporary files.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed statistics output for secondary storage.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

-   Fixed a problem when copying a cache entry from secondary storage
    into an empty primary storage.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Visual Studio .rsp files with UTF-16LE encoding are now handled
    correctly.\
    [*\[contributed by Vili Väinölä\]*]{.small}

-   Made conversion to relative paths more reliable on Windows.\
    [*\[contributed by Marius Zwicker\]*]{.small}

-   The process umask is now respected when making hard linked files
    read only.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   A forced recache is no longer considered a "direct cache miss".\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Documentation improvements {#_documentation_improvements_18}

-   Corrected reference to the `debug_dir` option.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved documentation of `--config-path`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added documentation that compiler plugins are hashed too.\
    [*\[contributed by Philipp Gortan\]*]{.small}

## Test improvements {#_test_improvements_17}

-   The "trim_dir" test suite is now only run when cleanup tests are
    enabled.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.5.1 {#_ccache_4_5_1}

Release date: 2021-11-17

## Bug fixes {#_bug_fixes_28}

-   Fixed entry_size field for result entries. This bug affected the
    recompression feature (`-X`/`--recompress`) in ccache 4.5.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   The actual compression level is now once again stored in the cache
    entry header.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Corrected error handling for non-constructible secondary storage
    backends. For instance, this avoids a crash when a Redis server
    can't be reached.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.5 {#_ccache_4_5}

Release date: 2021-11-13

## New features {#_new_features_3}

-   Made various improvements to the cache entry format. Among other
    things, the header now contains a creation timestamp and a note of
    the ccache version used to create the entry. The cache entry
    checksum has also been upgraded to use 128-bit XXH3 instead 64-bit
    XXH3.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added support for cache namespaces. If a namespace configured, e.g.
    using `CCACHE_NAMESPACE=some_string`, the namespace string will be
    added to the hashed data for each compilation. This will make the
    associated cache entries logically separate from cache entries in
    other namespaces, but they will still share the same storage space.
    Cache entries can also be selectively removed from the primary cache
    with the new command line option `--evict-namespace`, potentially in
    combination with `--evict-older-than`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made HTTP keep-alive configurable, defaulting to off for now.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Added support for rewriting absolute path to Clang option
    `--gcc-toolchain`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Compatibility notes {#_compatibility_notes_2}

-   A consequence of the changed cache entry format is that ccache 4.5
    will not share cache entries with earlier versions. Different ccache
    versions can however still use the same cache storage without any
    issues.

## Bug fixes {#_bug_fixes_29}

-   Fixed a problem with special characters in the user info part of
    URLs for HTTP storage.\
    [*\[contributed by Russell McClellan\]*]{.small}

-   Fixed win32 log messages about file locks.\
    [*\[contributed by Luboš Luňák\]*]{.small}

-   Fixed debug directory handling on Windows.\
    [*\[contributed by Luboš Luňák\]*]{.small}

-   The hard link and file clone features are now disabled when
    secondary storage is used since they only work for the local primary
    cache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.4.2 {#_ccache_4_4_2}

Release date: 2021-09-28

## Bug fixes {#_bug_fixes_30}

-   Fixed a bug introduced in 4.4 where ccache could produce false
    direct cache hits in some situations if it decides to disable the
    direct mode temporarily (e.g. due to "too new header" file).\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Test improvements {#_test_improvements_18}

-   Use shell builtin pwd command for basedir test.\
    [*\[contributed by Kira Bruneau\]*]{.small}

-   Cope with CC being a wrapper script that uses ccache.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.4.1 {#_ccache_4_4_1}

Release date: 2021-09-11

## New features {#_new_features_4}

-   The secondary storage statistics section of `-s/--show-stats` is now
    shown only if it's non-empty or with two verbose options.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added display of statistics counters for misses. Previously they
    were only implicit in the "hits + misses" sums.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes_31}

-   Fixed spurious crashes when using the HTTP or Redis backend and the
    remote connection hung up.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made sure to always store configuration origin value.\
    [*\[contributed by Gregor Jasny\]*]{.small}

## Build improvements {#_build_improvements_19}

-   The matching version of lld is now used for Clang.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   The standard linker is now used if IPO (LTO) is enabled.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Disabled IPO (LTO) for MinGW toolchains since they seem to be
    generally broken.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Fixed build errors with Clang on Windows.\
    [*\[contributed by Orgad Shaneh\]*]{.small}

## Test improvements {#_test_improvements_19}

-   Fixed .incbin test with newer binutil versions.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed basedir test suite failure when using a symlinked CWD.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved output of differing text files on failure.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

# Ccache 4.4 {#_ccache_4_4}

Release date: 2021-08-19

## New features {#_new_features_5}

-   Made it possible to share a cache over network or on a local
    filesystem. The configuration option
    `secondary_storage`/`CCACHE_SECONDARY_STORAGE` specifies one or
    several storage backends to query after the primary local cache
    storage. It is also possible to configure sharding (partitioning) of
    the cache to spread it over a server cluster using [Rendezvous
    hashing](https://en.wikipedia.org/wiki/Rendezvous_hashing). See the
    *[Secondary storage
    backends](https://ccache.dev/manual/4.4.html#_secondary_storage_backends)*
    chapter in the manual for details.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added an HTTP backend for secondary storage on any HTTP server that
    supports GET/PUT/DELETE methods. See [How to set up HTTP
    storage](https://ccache.dev/howto/http-storage.html) for hints on
    how to set up an HTTP server for use with ccache.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Added a Redis backend for secondary storage on any server that
    supports the Redis protocol. See [How to set up Redis
    storage](https://ccache.dev/howto/redis-storage.html) for hints on
    how to set up a Redis server for use with ccache.\
    [*\[contributed by Anders F Björklund\]*]{.small}

-   Added a filesystem backend for secondary storage. It can for
    instance be used for a shared cache over networked filesystems such
    as NFS, or for mounting a secondary read-only cache layer into a
    build container.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added `--trim-dir`, `--trim-max-size` and `--trim-method` options
    that can be used to trim a secondary storage directory to a certain
    size, e.g. via cron.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added a configuration option `reshare`/`CCACHE_RESHARE` which makes
    ccache send results to secondary storage even for primary storage
    cache hits.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added new statistics counters for direct/preprocessed cache misses,
    primary storage hits/misses, secondary storage
    hits/misses/errors/timeouts and forced recaches.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved statistics summary. The `-s`/`--show-stats` option now
    prints a more condensed overview where the counters representing
    "uncacheable calls" are summed as uncacheable and errors counters.
    The summary shows hit rate for direct/preprocessed hits/misses, as
    well as primary/secondary storage hits/misses. More details are
    shown with `-v`/`--verbose`. Note: Scripts should use
    `--print-stats` (available since ccache 3.7) instead of trying to
    parse the output of `--show-stats`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added a "stats log" feature (configuration option
    `stats_log`/`CCACHE_STATSLOG`), which tells ccache to store
    statistics in a separate log file specified by the user. It can for
    instance be used to collect statistics for a single build without
    interference from other concurrent builds. Statistics from the log
    file can then be viewed with `ccache --show-log-stats`.\
    [*\[contributed by Anders F Björklund\]*]{.small}

-   Added support for clang's `--config` option.\
    [*\[contributed by Tom Stellard\]*]{.small}

-   Added support for one `-Xarch_*` option that matches a corresponding
    `-arch` option.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Renamed the `--directory` option to `--dir` for consistency with
    other options.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made the `--config-path` and `--dir` options affect the whole
    command line so that they don't have to be put before
    `-s`/`--show-stats`.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made `--dump-manifest` and `--dump-result` accept filename `-` for
    reading from standard input.\
    [*\[contributed by Anders F Björklund\]*]{.small}

-   Made the output of `--print-stats` sorted.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Added more internal trace points.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

## Bug fixes {#_bug_fixes_32}

-   Fixed a crash if using `base_dir` and `$PWD` is set to a relative
    path.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed a bug with `-fprofile-generate` where ccache could give false
    positive cache hits when compiling with relative paths in another
    directory.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed a bug in `debug_dir`/`CCACHE_DEBUGDIR`. The absolute path to
    the object file was not created correctly if the object file didn't
    already exist.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Disabled preprocessor hits for pre-compiled headers with Clang
    again.\
    [*\[contributed by Arne Hasselbring\]*]{.small}

-   Fixed a problem when using the Gold linker on MIPS by only probing
    for a faster linker in dev build mode and on x86_64.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Made the `-DENABLE_TRACING=1` mode work again.\
    [*\[contributed by Anders F Björklund\]*]{.small}

## Changed tooling {#_changed_tooling_2}

-   A C++14 compiler or newer is now required to build ccache. For GCC,
    this means version 6 or newer in practice.

-   CMake 3.10 or newer is now required to build ccache.

-   [Asciidoctor](https://asciidoctor.org) is now required to build
    ccache documentation.

## Build/test/documentation improvements {#_buildtestdocumentation_improvements}

-   Fixed an issue in the modules test suite that showed up when running
    the ccache test suite with the clang wrapper provided by Nixpkgs.\
    [*\[contributed by Ryan Burns\]*]{.small}

-   Made the nvcc_ldir test suite require a working NVCC.\
    [*\[contributed by Michael Kruse\]*]{.small}

-   Made the ivfsoverlay test suite more robust.\
    [*\[contributed by Michael Kruse\]*]{.small}

-   Fixed issue with usage of `/FI` when building ccache with MSVC.\
    [*\[contributed by Michael Kruse\]*]{.small}

-   Fixed Apple Clang detection in the integration test suite.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Made clang the default compiler when running the test suite on
    macOS.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Silenced stray printout from \"-P -c\" test case.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Fixed selection of the ccache binary to use when running the test
    suite with multi-config generators like Xcode.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Fixed CMake feature detection for `ctim`/`mtim` fields in
    `struct stat`.\
    [*\[contributed by Gregor Jasny\]*]{.small}

-   Fixed issue with not linking to .lib correctly on Windows.\
    [*\[contributed by R. Voggenauer\]*]{.small}

-   Made it possible to override `CCACHE_DEV_MODE` on the command line.\
    [*\[contributed by Joel Rosdahl\]*]{.small}

-   Improved HTML documentation style.\
    [*\[contributed by Joel Rosdahl with minor fixes by Orgad
    Shaneh\]*]{.small}

# Ccache 4.3 {#_ccache_4_3}

Release date: 2021-05-09

## New features {#_new_features_6}

-   Ccache now ignores the Clang compiler option `-ivfsoverlay` and its
    argument if you opt in to "ivfsoverlay sloppiness". This is useful
    if you use Xcode, which uses a virtual file system (VFS) for things
    like combining Objective-C and Swift code.

-   When using `-P` in combination with `-E`, ccache now reports this as
    "called for preprocessing" instead of "unsupported compiler option".

-   Added support for `-specs file.specs` and `--specs file.specs`
    without an equal sign between the arguments.

## Bug fixes {#_bug_fixes_33}

-   "Split dwarf" code paths are now disabled when outputting to
    `/dev/null`. This avoids an attempt to delete `/dev/null.dwo`.

-   Made the `stat`/`lstat` wrapper function for Windows treat pending
    deletes as missing files.

-   Fixed a bug that made ccache process header files redundantly for
    some relative headers when using Clang.

-   The object path is now included in the input hash when using
    `-fprofile-arcs` (or `--coverage`) since the object file embeds a
    `.gcda` path based on the object file path.

## Build improvements {#_build_improvements_20}

-   Added an `ENABLE_DOCUMENTATION` build option (default: true) that
    can be used to disable the build of documentation.

-   Fixed detection of pthread features.

-   Quote CMake variables expansions to avoid errors when
    `${CMAKE_C_FLAGS_RELWITHDEBINFO}` or
    `${CMAKE_CXX_FLAGS_RELWITHDEBINFO}` expands to the empty string.

# Ccache 4.2.1 {#_ccache_4_2_1}

Release date: 2021-03-27

## Bug fixes {#_bug_fixes_34}

-   Ccache now only duplicates the stderr file descriptor into
    `$UNCACHED_ERR_FD` for calls to the preprocessor/compiler. This
    works around a complex bug in interaction with GNU Make, LTO linking
    and the Linux PTY driver.

-   Fixed detection of color diagnostics usage when using
    `-Xclang -fcolor-diagnostics` options.

-   The `-frecord-gcc-switches` compiler option is now handled correctly
    to avoid false positive cache hits.

-   Made it possible for per-compilation debug log files to be written
    in most argument processing error scenarios. Previously, ccache
    would only write debug log files if the argument processing phase
    was successful.

-   Made ccache bail out on too hard Clang option
    `-gen-cdb-fragment-path`.

-   The `run_second_cpp` made is now enforced on macOS if `-g` is used
    since newer Clang versions on macOS produce different debug
    information when compiling preprocessed code.

-   Made ccache only reject `-f(no-)color-diagnostics` for a known GCC
    compiler. This fixes a problem when using said option with Clang on
    macOS.

-   Implemented a better `stat`/`lstat` wrapper function for Windows.

-   Fixed a bug where ccache could return stale cache results on
    Windows.

-   Fixed handling of long command lines on Windows.

## Portability and build improvements {#_portability_and_build_improvements}

-   Build configuration scripts now probe for atomic increment as well.
    This fixes a linking error on Sparc.

-   An existing CMake log message level is now used when warning about
    not finding asciidoc.

-   Added support for building ccache with xlclang++ on AIX 7.2.

-   Fixed assertion in the "Debug option" test.

-   Made build configuration skip using ccache when building with MSVC.

-   Upgraded to doctest 2.4.6. This fixes a build error with glibc \>=
    2.34.

## Documentation {#_documentation}

-   Fixed markup of `compiler_type` value `other`.

-   Fixed markup of `debug_dir` documentation.

-   Fixed references to the `extra_files_to_hash` configuration option.

# Ccache 4.2 {#_ccache_4_2}

Release date: 2021-02-02

## New features {#_new_features_7}

-   Improved calculation of relative paths when using `base_dir` to also
    consider canonical paths (i.e. paths with dereferenced symlinks) as
    candidates.

-   Added a `debug_dir` (`CCACHE_DEBUGDIR`) configuration setting for
    specifying a directory for files written in debug mode.

-   Added support for compiler option `-x cuda`, understood by Clang.

-   The value of the `SOURCE_DATE_EPOCH` variable is now only hashed if
    it potentially affects the output from ccache. This means that
    ccache now (like before version 4.0) will be able to produce cache
    hits for source code that doesn't contain `__DATE__` or `__TIME__`
    macros regardless of the value of `SOURCE_DATE_EPOCH`.

## Bug fixes {#_bug_fixes_35}

-   Fixed a bug where a non-Clang compiler would silently accept the
    Clang-specific `-f(no-)color-diagnostics` option when run via
    ccache. This confused feature detection made by e.g. CMake.

-   Improved creation of temporary files on Windows. Previously, ccache
    would in practice reuse temporary filenames on said platform
    resulting in various problems with parallel builds.

-   Fixed creation of parent directories when creating a lock file on
    Windows.

-   Fixed a race condition related to removal of temporary files.

-   Improved calculation of directory name for a Windows-style path.

-   A compilation result is now not stored in the cache if an included
    preprocessed header file is too new. This fixes a bug where the
    content of a newly created preprocessed header file could be missing
    from the hash, resulting in a false positive cache hit.

-   Fixed calculation of the split DWARF filename for an object filename
    with zero or multiple dots.

-   Fixed retrieval of the object file the destination is `/dev/null`.

## Portability and build improvements {#_portability_and_build_improvements_2}

-   Additional compiler flags like `-Wextra -Werror` are now only added
    when building ccache in developer mode.

-   The developer build mode no longer enables `-Weverything` for Clang.

-   `_XOPEN_SOURCE` is now defined appropriately on FreeBSD to fix
    missing declaration of `isascii`.

-   Improved detection of buildability of BLAKE3 assembler files.

-   Disabled build of inode cache code on OSes without
    `pthread_mutexattr_setpshared`, such as OpenBSD.

-   Made static linking the default for a Windows MinGW build.

-   Removed legacy fallback replacements of `mkstemp` and `realpath`.

-   Improved detection of SSE/AVX support.

-   Improved detection of support for the AVX2 target attribute.

-   Configuration scripts now try to detect and enable BLAKE3's Neon
    support.

-   Made it possible to run the integration test suite on macOS.

-   Fixed building of 32-bit unit tests on macOS.

-   Made it possible to compile ccache for C++17.

-   Fixed printing of 64-bit `time_t` on 32-bit architectures like
    RISCV32.

-   Made sure to only use ASCII characters in the manual's AsciiDoc
    source code to make it possible to generate documentation in
    non-UTF8 locales.

-   Upgraded to optional-lite 3.4.0, fmt 7.1.3, doctest 2.4.4 and zstd
    1.4.8.

-   Took steps towards being able to run the test suite on Windows.

## Documentation {#_documentation_2}

-   Improved wording of `compiler_check` string values.

-   Improved documentation of compression levels and the
    `-X/--recompress` option.

-   Improved consistency of terms in the manual.

-   HTML documentation is now built and installed by default if
    possible.

-   Fixed incorrect documentation of configuration option `cache_dir`.

-   Added hint on how to link statically with libzstd.

-   Mention that ccache requires the `-c` compiler option.

# Ccache 4.1 {#_ccache_4_1}

Release date: 2020-11-22

## New features {#_new_features_8}

-   Symlinks are now followed when guessing the compiler. This makes
    ccache able to guess compiler type "GCC" for a common symlink chain
    like this: `/usr/bin/cc` → `/etc/alternatives/cc` → `/usr/bin/gcc` →
    `gcc-9` → `x86_64-linux-gnu-gcc-9`.

-   Added a new `compiler_type` (`CCACHE_COMPILERTYPE`) configuration
    option that allows for overriding the guessed compiler type.

-   Added support for caching compilations with `-fsyntax-only`.

-   Added a command line option `--config-path`, which specifies the
    configuration file to operate on. It can be used instead of setting
    `CCACHE_CONFIGPATH` temporarily.

## Bug fixes {#_bug_fixes_36}

-   The original color diagnostics options are now retained when forcing
    colored output. This fixes a bug where feature detection of the
    `-fcolor-diagnostics` option would succeed when run via ccache even
    though the actual compiler doesn't support it (e.g. GCC \<4.9).

-   Fixed a bug related to umask when using the `umask` (`CCACHE_UMASK`)
    configuration option.

-   Allow `ccache ccache compiler …​` (repeated `ccache`) again.

-   Fixed parsing of dependency file in the "depend mode" so that
    filenames with space or other special characters are handled
    correctly.

-   Fixed rewriting of the dependency file content when the object
    filename includes space or other special characters.

-   Fixed runtime detection of AVX2 support, not relying on the
    sometimes broken `__builtin_cpu_support` routine.

-   Added missing parameters to a log call, thus avoiding a crash when
    it is found out at runtime that file cloning is unsupported by the
    OS.

## Portability and build fixes {#_portability_and_build_fixes}

-   The ccache binary is now linked with `libatomic` if needed. This
    fixes build problems with GCC on ARM and PowerPC.

-   Fixed build of BLAKE3 code with Clang 3.4 and 3.5.

-   Fixed "use of undeclared identifier \'CLONE_NOOWNERCOPY\'" build
    error on macOS 10.12.

-   Fixed build problems related to missing AVX2 and AVX512 support on
    older macOS versions.

-   Fixed static linkage with libgcc and libstdc++ for MinGW and made it
    optional.

-   Fixed conditional compilation of "robust mutex" code for the inode
    cache routines.

-   Fixed badly named man page filename (`Ccache.1` instead of
    `ccache.1`).

-   Disabled some tests on ancient Clang versions.

## Other improvements and fixes {#_other_improvements_and_fixes}

-   The man page is now built by default if the required tools are
    available.

-   Use CMake `A2X_EXE` variable instead of hardcoded `a2x`.

-   Improved build errors when building ccache with very old compiler
    versions.

-   Fall back to version "unknown" when Git is not installed.

-   Documented the relationship between `CCACHE_DIR` and
    `-d/--directory`.

-   Fixed incorrect reference and bad markup in the manual.

# Ccache 4.0 {#_ccache_4_0}

Release date: 2020-10-18

## Summary of major changes {#_summary_of_major_changes}

-   Changed the default cache directory location to follow the XDG base
    directory specification.

-   Changed compression algorithm from Deflate (zlib) to Zstandard,
    enabled by default.

-   Added functionality for recompressing cache content with a higher
    compression level.

-   Changed hash algorithm from MD4 to BLAKE3.

-   Added checksumming with XXH3 to detect data corruption.

-   Improved cache directory structure.

-   Added support for using file cloning (AKA "reflinks").

-   Added an experimental "inode cache" for file hashes.

## Compatibility notes {#_compatibility_notes_3}

-   The default location of the cache directory has changed to follow
    the XDG base directory specification ([more details
    below](#_detailed_functional_changes)). This means that scripts can
    no longer assume that the cache directory is `~/.ccache` by default.
    The `CCACHE_DIR` environment variable still overrides the default
    location just like before.

-   The cache directory structure has changed compared to previous
    versions ([more details below](#_detailed_functional_changes)). This
    means that ccache 4.0 will not share cache results with earlier
    versions. It is however safe to run ccache 4.0 and earlier versions
    against the same cache directory: cache bookkeeping, statistics and
    cleanup are backward compatible, with the minor exception that some
    statistics counters incremented by ccache 4.0 won't be visible when
    running `ccache -s` with an older version.

## Changed tooling {#_changed_tooling_3}

-   CMake is now used instead of Autoconf for configuration and
    building.

-   A C++11 compiler, a C99 compiler and CMake 3.4.3 or newer are now
    required to build ccache.

-   Ccache can now be built using Microsoft Visual C++.

## Detailed functional changes {#_detailed_functional_changes}

-   All data of a cached result is now stored in a single file called
    "result" instead of up to seven files. This reduces inode usage and
    improves data locality.

-   Added compression of result and manifest files using the
    [Zstandard](https://facebook.github.io/zstd/) algorithm. Compression
    is enabled by default with compression level 1. This makes ccache
    able to store more data in the cache. Previously compression using
    Deflate (zlib) was available but disabled by default. Files can be
    recompressed with another compression level later with the
    `-X/--recompress` option described further below.

-   Changed from MD4 to [BLAKE3](https://blake3.io) for hashing input.
    This improves performance and reduces the risk of hash collisions.

-   Added checksumming of result and manifest files using the
    [XXH3](https://xxhash.com) algorithm to detect data corruption.

-   Ccache now follows the [XDG base directory
    specification](https://specifications.freedesktop.org/basedir-spec/).
    This means that the default cache directory on Unix systems is
    `$XDG_CACHE_HOME/ccache` (with `~/.cache/ccache` as the fallback if
    `XDG_CACHE_HOME` is not set) and the configuration file is
    `$XDG_CONFIG_HOME/ccache/ccache.conf` (with
    `~/.config/ccache/ccache.conf` as the fallback). On macOS, the
    fallbacks are `~/Library/Caches/ccache` and
    `~/Library/Preferences/ccache/ccache.conf`. On Windows, the
    fallbacks are `%APPDATA%/ccache` and `%APPDATA%/ccache/ccache.conf`.
    Exception: If the legacy `~/.ccache` directory exists, that
    directory is used as the default cache location and the
    configuration file is `~/.ccache/ccache.conf`.

-   Cache statistics are now stored in files on cache level 2 to reduce
    lock contention when there are many parallel compilations.

-   An appropriate cache directory level structure is now chosen
    automatically. The `cache_dir_levels` (`CCACHE_NLEVELS`)
    configuration option has therefore been removed.

-   Added an experimental "inode cache" for file hashes, allowing
    computed hash values to be reused both within and between builds.
    The inode cache is off by default but can be enabled by setting
    `inode_cache` (`CCACHE_INODECACHE`) to `true`.

-   Added support for using file cloning (AKA "reflinks") on Btrfs, XFS
    and APFS to copy data to and from the cache very efficiently.

-   Two measures have been implemented to make the hard link mode safer:
    hard-linked files are made read-only and inadvertent content changes
    that affect file size are detected.

-   Added a command line option `-x/--show-compression` which shows
    statistics about cache compression.

-   Added a command line option `-X/--recompress` which recompresses the
    cache data with another compression level or makes it uncompressed.
    If you choose to disable compression by default, or choose to use a
    compression level with a low compression ratio, you can recompress
    the cache with a higher compression level after the build or at
    another time when there are more CPU cycles available, for instance
    every night. Only files that are currently compressed with a
    different level than the wanted level will be recompressed.

-   Added a command line option `--evict-older-than` which removes cache
    entries older than a certain age.

-   Added a command line option `-d/--directory` which specifies a cache
    directory to operate on. It can be used instead of setting
    `CCACHE_DIR` temporarily.

-   A progress bar has been added to show the progress of time-consuming
    options like `-c/--cleanup`, `-C/--clear`, `--evict-older-than`,
    `-x/--show-compression` and `-X/--recompress`.

-   When supported by the CPU, a SIMD-friendly (using AVX2) algorithm is
    now used to scan input source code for `__DATE__`, `__TIME__` and
    `__TIMESTAMP__` macros. This can decrease the number of CPU cycles
    for a direct cache hit with up to 15% in some cases.

-   Some unnecessary `stat(2)` system calls are now avoided when
    verifying header files.

-   Compiler diagnostic messages are now always cached in color. Ccache
    then strips the color codes on the fly when requested explicitly by
    a command line option or when stderr does not refer to a TTY. This
    allows IDEs and terminals to share cached compilation results.

-   The configuration option `compiler` (`CCACHE_COMPILER`) now always
    takes effect if specified. Previously, the configuration option was
    only used when the compiler specified on the command line was looked
    up via `PATH` (i.e., not when an absolute path was specified).

-   Added optional logging to syslog if `log_file` (`CCACHE_LOGFILE`) is
    set to `syslog`.

-   The compiler option `-fmodules` is now handled in the "depend mode".
    If "depend mode" is disabled the option is still considered too hard
    and ccache will fall back to running the compiler.

-   Ccache can now cache compilations with coverage notes (`.gcno`
    files) produced by GCC 9+ in combination with `-fprofile-dir=dir`.

-   `realpath(3)` is no longer used for normalization when computing
    relative paths. This makes it possible to get cache hits when the
    source or build directory is a symbolic link to an absolute path
    that includes unstable information like build IDs or timestamps.

-   Added an `ignore_options` (`CCACHE_IGNOREOPTIONS`) configuration
    option which makes it possible to exclude compiler options from the
    hash.

-   Added an `absolute_paths_in_stderr` (`CCACHE_ABSSTDERR`)
    configuration option which makes ccache rewrite absolute paths in
    compiler warnings and errors to relative.

-   Improved handling of umask. The configured `umask` (`CCACHE_UMASK`)
    is now only applied to files and directories in the cache directory.
    Previously the umask was applied to all files produced by ccache and
    the executed compiler.

-   Ccache is now able to share cache entries for different object file
    names when using `-MD` or `-MMD`.

-   Clang's `-Xclang` (used by CMake for precompiled headers),
    `-fno-pch-timestamp`, `-emit-pch`, `-emit-pth` and `-include-pth`
    options are now understood.

-   Added support for the HIP ("C++ Heterogeneous-Compute Interface for
    Portability") language.

-   The manifest format now allows for header files larger than 4 GiB.

-   Made it possible to once again cache compilations with `__DATE__` in
    the source code.

-   Added handling of the `__TIMESTAMP__` macro.

-   An absolute input source path is now rewritten to a relative path
    when using `base_dir`.

-   `waitpid` system calls interrupted by a signal are now handled
    correctly.

-   Made handling of `.dwo` files and interaction between
    `-gsplit-dwarf` and other `-g*` options more robust.

-   The "couldn't find compiler" statistics counter is no longer
    incremented when ccache exits with a fatal error.

-   Failure to run a `compiler_check` command is no longer a fatal
    error.

-   Added command line options `--dump-result` and `--extract-result`
    for inspecting and extracting result files.

-   Added a command line option `--checksum-file` for debugging or
    evaluating the checksum algorithm.

-   Improved error message for `ccache -o=K=V` (trying to set a
    configuration option named `=K`).

-   Made timestamps in statistics files Y2038-proof.

-   Removed code for populating a newly created configuration file with
    max cache size and max files values for cache directories created by
    ccache versions older than 3.2 (released 2014).

-   Removed knowledge about a top-level `stats` file created by ccache
    versions older than 3.1 (released 2010).

## Other improvements {#_other_improvements_2}

-   Improved help text and documentation of command line options.

-   Improved documentation of the `base_dir` configuration option.

-   Improved documentation of preprocessor and direct modes.

-   Added HTML anchors to configuration options in the manual so that it
    is possible link to a specific option.

-   Tweaked placement of "(readonly)" in output of `ccache -s`.

-   Improved visibility of color output from the test suite.

-   Fixed a problem when running the test suite with Clang without a
    libgcov library available.

-   Fixed test suite problems on macOS.

-   Disabled hardlink tests on AFS since it lacks such support.

-   Disabled read-only tests on file systems that lack such support.

# Ccache 3.7.12 {#_ccache_3_7_12}

Release date: 2020-10-01

## Bug fixes {#_bug_fixes_37}

-   Coverage files (`.gcno`) produced by GCC 9+ when using
    `-fprofile-dir=dir` are now handled gracefully by falling back to
    running the compiler.

-   Fixed writing to log file larger than 2 GiB when running ccache
    compiled in 32-bit mode.

## Other {#_other_3}

-   Improved documentation about sharing a cache on NFS.

-   Fixed test case failures with old objdump versions.

-   Fixed test case failures with GCC 4.4.

# Ccache 3.7.11 {#_ccache_3_7_11}

Release date: 2020-07-21

## Bug fixes {#_bug_fixes_38}

-   Added knowledge about
    `-fprofile-{correction,reorder-functions,values}`.

-   ccache now handles the Intel compiler option `-xCODE` (where `CODE`
    is a processor feature code) correctly.

-   Added support for NVCC's `-Werror` and `--Werror` options.

## Other {#_other_4}

-   ccache's "Directory is not hashed if using -gz\[=zlib\]" tests are
    now skipped for GCC 6.

# Ccache 3.7.10 {#_ccache_3_7_10}

Release date: 2020-06-22

## Bug fixes {#_bug_fixes_39}

-   Improved handling of profiling options. ccache should now work
    correctly for profiling options like
    `-fprofile-{generate,use}[=path]` for GCC ≥ 9 and Clang as well as
    `-fauto-profile[=path]` and the Clang-specific
    `-fprofile-instr-{generate,use}[=path]` and
    `-fprofile-sample-{use,accurate}` options.

-   ccache now copies files directly from the cache to the destination
    file instead of via a temporary file. This avoids problems when
    using filenames long enough to be near the file system's filename
    max limit.

-   When the hard-link mode is enabled, ccache now only uses hard links
    for object files, not other files like dependency files. This is
    because compilers unlink object files before writing to them but
    they don't do that for dependency files, so the latter can become
    overwritten and therefore corrupted in the cache.

-   Fixed a glitch related to hard-link mode and an empty cache.

-   ccache now supports the ccache.conf file to be a symlink.

-   Temporary files are now deleted immediately on signals like SIGTERM
    and SIGINT instead of some time later in a cleanup phase.

-   Fixed a bug that affected ccache's `-o/--set-config` option for the
    `base_dir` and `cache_dir_levels` keys.

# Ccache 3.7.9 {#_ccache_3_7_9}

Release date: 2020-03-29

## Bug fixes {#_bug_fixes_40}

-   Fixed replacing of /dev/null when building as root with hard link
    mode enabled and using `-o /dev/null`.

-   Removed incorrect assertion resulting in "ccache: error: Internal
    error in format" when using `-fdebug-prefix-map=X=` with X equal to
    `$PWD`.

## Other {#_other_5}

-   Improved CUDA/NVCC support: Recognize `-dc` and `-x cu` options.

-   Improved name of temporary file used in NFS-safe unlink.

# Ccache 3.7.8 {#_ccache_3_7_8}

Release date: 2020-03-16

## Bug fixes {#_bug_fixes_41}

-   Use `$PWD` instead of the real CWD (current working directory) when
    checking for CWD in preprocessed output. This fixes a problem when
    `$PWD` includes a symlink part and the user has set
    `hash_dir = false`.

-   Rewrote the Windows version of the lockfile routines. This should
    mitigate several problems with the old implementation.

-   If `localtime_r` fails the epoch time is now logged instead of
    garbage.

## Other {#_other_6}

-   Improved error message when a boolean environment variable has an
    invalid value.

-   Improved the regression fix in ccache 3.7.5 related to not passing
    compilation-only options to the preprocessor.

-   ccache's PCH test suite now skips running the tests if it detects
    broken PCH compiler support.

-   Fixed unit test failure on Windows.

-   Fixed "stringop-truncation" build warning on Windows.

-   Improved "x_rename" implementation on Windows.

-   Improved removal of temporary file when rewriting absolute paths to
    relative in the dependency file.

-   Clarified "include_file_ctime sloppiness" in the Performance section
    in the manual.

# Ccache 3.7.7 {#_ccache_3_7_7}

Release date: 2020-01-05

## Bug fixes {#_bug_fixes_42}

-   Fixed a bug related to object file location in the dependency file
    (if using `-MD` or `-MMD` but not `-MF` and the build directory is
    not the same as the source directory then the object file location
    in the `.d` file would become incorrect). This fixes regression in
    ccache 3.7.5 introduced by the bug fix related to EDG-based
    compilers. Note that this removes support for EDG-based compilers
    again. (A better fix for this is planned for ccache 4.0.)

-   Removed the unify mode since it has bugs and shortcomings that are
    non-trivial or impossible to fix: it doesn't work with the direct
    mode, it doesn't handle C++ raw strings correctly, it can give false
    cache hits for `.incbin` directives, it's turned off when using `-g`
    and it can make line numbers in warning messages and `LINE` macros
    incorrect.

-   mtime and ctime values are now stored in the manifest files only
    when sloppy_file_stat is set. This avoids adding superfluous
    manifest file entries on direct mode cache misses.

-   A "Result:" line is now always printed to the log.

-   The "cache miss" statistics counter will now be updated for
    read-only cache misses, making it consistent with the cache hit
    case.

# Ccache 3.7.6 {#_ccache_3_7_6}

Release date: 2019-11-17

## Bug fixes {#_bug_fixes_43}

-   The opt-in "file_macro sloppiness" mode has been removed so that the
    input file path now is always included in the direct mode hash. This
    fixes a bug that could result in false cache hits in an edge case
    when "file_macro sloppiness" is enabled and several identical source
    files include a relative header file with the same name but in
    different directories.

-   Statistics files are no longer lost when the filesystem of the cache
    is full.

-   Bail out on too hard Clang option `-MJarg` (in addition to the
    previous bailout of `-MJ arg`).

-   Properly handle color diagnostics in the depend mode as well.

# Ccache 3.7.5 {#_ccache_3_7_5}

Release date: 2019-10-22

## New features {#_new_features_9}

-   Added support for `-MF=arg` (with an extra equal sign) as understood
    by EDG-based compilers.

## Bug fixes {#_bug_fixes_44}

-   Fixed a regression in 3.7.2 that could result in a warning message
    instead of an error in an edge case related to usage of "-Werror".

-   An implicit `-MQ` is now passed to the preprocessor only if the
    object file extension is non-standard. This will make it easier to
    use EDG-based compilers (e.g. GHS) which don't understand `-MQ`.
    (This is a bug fix of the corresponding improvement implemented in
    ccache 3.4.)

-   ccache now falls back to running the real compiler instead of
    failing fataly if an internal temporary file is missing after
    compilation.

-   Fixed a crash if localtime returns null pointer in localtime_r
    replacement.

-   Fixed header file dependency tracking when building ccache itself.

-   Fixed warning during configure in out-of-tree build in developer
    mode.

# Ccache 3.7.4 {#_ccache_3_7_4}

Release date: 2019-09-12

## Improvements {#_improvements}

-   Added support for the `-gz[=type]` compiler option (previously
    ccache would think that "-gz" alone would enable debug information,
    thus potentially including the current directory in the hash).

-   Added support for converting paths like "/c/users/...​" into relative
    paths on Windows.

# Ccache 3.7.3 {#_ccache_3_7_3}

Release date: 2019-08-17

## Bug fixes {#_bug_fixes_45}

-   The cache size (which is counted in "used disk blocks") is now
    correct on filesystems that use more or less disk blocks than
    conventional filesystems, e.g. ecryptfs or btrfs/zfs with
    transparent compression. This also fixes a related problem with
    ccache's own test suite when run on such file systems.

-   Fixed a regression in 3.7.2 when using the compiler option "-Werror"
    and then "-Wno-error" later on the command line.

# Ccache 3.7.2 {#_ccache_3_7_2}

Release date: 2019-07-19

## Bug fixes {#_bug_fixes_46}

-   The compiler option `-gdwarf*` no longer forces "run_second_cpp =
    true".

-   Added verification that the value passed to the `-o/--set-config`
    option is valid.

-   Fixed detection of precompiled headers in the depend mode.

-   Bail out on too hard Clang option `-ftime-trace`.

-   ccache now updates the correct stats file when adding/updating
    manifest files. This bug previously made the file and size
    statistics counters incorrect over time.

-   Fixed warnings from Clang about unused arguments during
    preprocessing.

-   Unknown manifest versions are now handled gracefully in
    `--dump-manifest`.

-   Fixed `make check` with "funny" locales.

## Documentation {#_documentation_3}

-   Added a hint about not running `autogen.sh` when building from a
    release archive.

-   Mention that `xsltproc` is needed when building from the source
    repository.

# Ccache 3.7.1 {#_ccache_3_7_1}

Release date: 2019-05-01

## Changes {#_changes}

-   Fixed a problem when using the compiler option `-MF /dev/null`.

-   Long commandlines are now handled gracefully on Windows by using the
    `@file` syntax to avoid hitting the commandline size limit.

-   Fixed complaint from GCC 9's `-Werror=format-overflow` when
    compiling ccache itself.

# Ccache 3.7 {#_ccache_3_7}

Release date: 2019-04-23

## Changes {#_changes_2}

-   Fixed crash when the debug mode is enabled and the output file is in
    a non-writable directory, e.g. when the output file is `/dev/null`.

-   Fixed an issue when printing very large log messages to the debug
    log.

-   Fixed bugs related to support for `-gsplit-dwarf`. Previously ccache
    could produce an incorrect link to the `.dwo` file in the `.o` file.

-   Compilations with /dev/null as the input file are now cached.

-   ccache has learned how to construct the object filename if no `-o`
    option is given and the source filename does not include a `.` or
    ends with a `.`.

-   Fixed a temporary file leak when the depend mode is enabled and the
    compiler produces standard error output.

-   Fixed a bug in the depend mode where a manifest hash only could be
    associated with one set of header dependencies.

-   Manifest files did not get marked as used on direct cache hits, so
    the LRU cache cleanup would incorrectly remove them eventually. This
    has been fixed.

-   The rewriting of absolute paths into relative paths in the
    dependency file has been enabled in the depend mode as well.

-   ccache now ignores unknown keys in configuration files for forward
    compatibility.

-   Rearranged command-line options into sections in the help text.

-   Documented the previously undocumented `--dump-manifest` and
    `--hash-file` options (only useful for debugging ccache itself).

-   Added missing documentation for the command-line option
    `-k/--get-config` added in ccache 3.5.

-   Renamed the `--print-config` command to `--show-config`.

-   Added a new `--print-stats` command that prints statistics counters
    in machine-parsable (tab-separated) format.

-   ccache no longer creates a missing output directory, thus mimicking
    the compiler behavior for `-o out/obj.o` when `out` doesn't exist.

-   `-fdebug-prefix-map=ARG`, `-ffile-prefix-map=ARG` and
    `-fmacro-prefix-map=ARG` are now included in the hash, but only the
    part before "ARG". This fixes a bug where compiler feature detection
    of said flags would not work correctly with ccache.

-   Bail out on too hard compiler option `-gtoggle`.

-   Bail out on too hard Clang options `--analyze` and `-analyze`.

-   Improved debug logging of file hashes in depend mode.

-   Improved handling of various `-g*` options. In particular, ccache
    now understands that `-g0` cancels out previous `-g* options`.

-   Worked around a problem with Automake related to `.d` files when
    using the hard link mode.

-   Added opt-in (at configure time) support for enabling trace logs for
    profiling ccache itself. See `doc/DEVELOPER.md` in the code tree for
    more information

-   Removed support for Fortran 77 again. Some Fortran support was added
    in ccache 3.3, but the implementation did not work when Fortran
    modules are involved.

# Ccache 3.6 {#_ccache_3_6}

Release date: 2019-01-14

## Changes {#_changes_3}

-   ccache now has an opt-in "depend mode". When enabled, ccache never
    executes the preprocessor, which results in much lower cache miss
    overhead at the expense of a lower potential cache hit rate. The
    depend mode is only possible to use when the compiler option `-MD`
    or `-MMD` is used.

-   Added support for GCC's `-ffile-prefix-map` option. The
    `-fmacro-prefix-map` option is now also skipped from the hash.

-   Added support for multiple `-fsanitize-blacklist` arguments.

-   ccache now includes the environment variables `LANG`, `LC_ALL`,
    `LC_CTYPE` and `LC_MESSAGES` in the hash since they may affect
    localization of compiler warning messages. Set sloppiness to
    `locale` to opt out of this.

-   Fixed a problem due to Clang overwriting the output file when
    compiling an assembler file.

-   Clarified the manual to explain the reasoning behind the
    "file_macro" sloppiness setting in a better way.

-   ccache now handles several levels of nonexistent directories when
    rewriting absolute paths to relative.

-   A new sloppiness setting `clang_index_store` makes ccache skip the
    Clang compiler option `-index-store-path` and its argument when
    computing the manifest hash. This is useful if you use Xcode, which
    uses an index store path derived from the local project path. Note
    that the index store won't be updated correctly on cache hits if you
    enable this option.

-   Rename sloppiness `no_system_headers` to `system_headers` for
    consistency with other options. `no_system_headers` can still be
    used as an (undocumented) alias.

-   The GCC variables "DEPENDENCIES_OUTPUT" and "SUNPRO_DEPENDENCIES"
    are now supported correctly.

-   The algorithm that scans for `_DATE` and `__TIME__` tokens in the
    hashed source code now doesn't produce false positives for tokens
    where `__DATE__` or `__TIME__` is a substring.

# Ccache 3.5.1 {#_ccache_3_5_1}

Release date: 2019-01-02

## Changes {#_changes_4}

-   Added missing getopt_long.c source file to release archive.

-   Fixed (harmless) compiler warnings when building ccache object
    files.

-   CFLAGS is no longer passed to the linker when linking ccache.

-   Improved development mode build flags.

# Ccache 3.5 {#_ccache_3_5}

Release date: 2018-10-15

## Changes {#_changes_5}

-   Added a boolean `debug` (`CCACHE_DEBUG`) configuration option. When
    enabled, ccache will create per-object debug files that are helpful
    e.g. when debugging unexpected cache misses. See also the new "Cache
    debugging" section in the manual.

-   Renamed `CCACHE_CC` to `CCACHE_COMPILER` (keeping the former as a
    deprecated alias).

-   Added a new command-line option `-k/--get-config` that prints the
    value of a config key.

-   It is now possible to let ccache hash a precomputed checksum file
    instead of the full content of a precompiled header. This can save
    time for large precompiled headers. Note that the build system needs
    to keep the checksum file in sync with the precompiled header for
    this to work.

-   Improved performance substantially when using `hash_dir = false` on
    platforms like macOS where `getcwd()` is slow.

-   Added "stats updated" timestamp in `ccache -s` output. This can be
    useful if you wonder whether ccache actually was used for your last
    build.

-   Renamed "stats zero time" to "stats zeroed" and documented it. The
    counter is also now only present in `ccache -s` output when
    `ccache -z` actually has been called.

-   The content of the `-fsanitize-blacklist` file is now included in
    the hash, so updates to the file will now correctly result in
    separate cache entries.

-   It's now possible to opt out of building and installing man pages
    when running `make install` in the source repository.

-   If the compiler type can't be detected (e.g. if it is named `cc`),
    use safer defaults that won't trip up Clang.

-   Made the ccache test suite work on FreeBSD.

-   Added `file_stat_matches_ctime` option to disable ctime check if
    `file_stat_matches` is enabled.

-   Made "./configure --without-bundled-zlib" do what's intended.

# Ccache 3.4.3 {#_ccache_3_4_3}

Release date: 2018-09-02

## Bug fixes {#_bug_fixes_47}

-   Fixed a race condition when creating the initial config file in the
    cache directory.

-   Bail out on too hard Clang option `-MJ`.

-   Bail out on too hard option `-save-temps=obj`.

-   Handle separate parameter to Clang option `-target` correctly.

-   Upgraded bundled zlib to version 1.2.11.

# Ccache 3.4.2 {#_ccache_3_4_2}

Release date: 2018-03-25

## Bug fixes {#_bug_fixes_48}

-   The cleanup algorithm has been fixed to not misbehave when files are
    removed by another process while the cleanup process is running.
    Previously, too many files could be removed from the cache if
    multiple cleanup processes were triggered at the same time, in
    extreme cases trimming the cache to a much smaller size than the
    configured limits.

-   Correctly hash preprocessed headers located in a ".gch directory".
    Previously, ccache would not pick up changes to such precompiled
    headers, risking false positive cache hits.

-   Fixed build failure when using the bundled zlib sources.

-   ccache 3.3.5 added a workaround for not triggering Clang errors when
    a precompiled header's dependency has an updated timestamp (but
    identical content). That workaround is now only applied when the
    compiler is Clang.

-   Made it possible to perform out-of-source builds in dev mode again.

# Ccache 3.4.1 {#_ccache_3_4_1}

Release date: 2018-02-11

## Bug fixes {#_bug_fixes_49}

-   Fixed printing of version number in `ccache --version`.

# Ccache 3.4 {#_ccache_3_4}

Release date: 2018-02-11

## New features and enhancements {#_new_features_and_enhancements}

-   The compiler option form `--sysroot arg` is now handled like the
    documented `--sysroot=arg` form.

-   Added support for caching `.su` files generated by GCC flag
    `-fstack-usage`.

-   ccache should now work with distcc's "pump" wrapper.

-   The optional unifier is no longer disabled when the direct mode is
    enabled.

-   Added support for NVCC compiler options `--compiler-bindir/-ccbin`,
    `--output-directory/-odir` and `--libdevice-directory/-ldir`.

-   Boolean environment variable settings no longer accept the following
    (case-insensitive) values: `0`, `false`, `disable` and `no`. All
    other values are accepted and taken to mean "true". This is to stop
    users from setting e.g. `CCACHE_DISABLE=0` and then expect the cache
    to be used.

-   Improved support for `run_second_cpp = false`: If combined with
    passing `-fdirectives-only` (GCC) or `frewrite-includes` (Clang) to
    the compiler, diagnostics warnings and similar will be correct.

-   An implicit `-MQ` is now passed to the preprocessor only if the
    object file extension is non-standard. This should make it easier to
    use EDG-based compilers (e.g. GHS) which don't understand `-MQ`.

-   ccache now treats an unreadable configuration file just like a
    missing configuration file.

-   Documented more pitfalls with enabling `hard_link`
    (`CCACHE_HARDLINK`).

-   Documented caveats related to colored warnings from compilers.

## Bug fixes {#_bug_fixes_50}

-   File size and number counters are now updated correctly when files
    are overwritten in the cache, e.g. when using `CCACHE_RECACHE`.

-   `run_second_cpp` is now forced for NVCC.

-   Fixed how the NVCC options `-optf` and `-odir` are handled.

# Ccache 3.3.6 {#_ccache_3_3_6}

Release date: 2018-01-28

## New features and enhancements {#_new_features_and_enhancements_2}

-   Improved instructions on how to get cache hits between different
    working directories.

## Bug fixes {#_bug_fixes_51}

-   Fixed regression in ccache 3.3.5 related to the `UNCACHED_ERR_FD`
    feature.

# Ccache 3.3.5 {#_ccache_3_3_5}

Release date: 2018-01-13

## New features and enhancements {#_new_features_and_enhancements_3}

-   Documented how automatic cache cleanup works.

## Bug fixes {#_bug_fixes_52}

-   Fixed a regression where the original order of debug options could
    be lost. This reverts the "Improved parsing of `-g*` options"
    feature in ccache 3.3.

-   Multiple `-fdebug-prefix-map` options should now be handled
    correctly.

-   Fixed matching of directories in the `ignore_headers_in_manifest`
    configuration option.

-   Fixed detection of missing argument to `-opt`/`--options-file`.

-   ccache now bails out when building a precompiled header if any of
    the corresponding header files has an updated timestamp. This fixes
    complaints from Clang.

-   Fixed a bug related to erroneously storing a dependency file with
    absolute paths in the cache on a preprocessed hit.

-   `ccache -c/--cleanup` now works like documented: it just
    recalculates size counters and trims the cache to not exceed the max
    size and file number limits. Previously, the forced cleanup took
    "limit_multiple" into account, so that `ccache -c/--cleanup` by
    default would trim the cache to 80% of the max limit.

-   ccache no longer ignores linker arguments for Clang since Clang
    warns about them.

-   Plugged a couple of file descriptor leaks.

-   Fixed a bug where ccache would skip hashing the compiler argument
    following a `-fno-working-directory`, `-fworking-directory`,
    `-nostdinc`, `-nostdinc++`, `-remap` or `-trigraphs` option in
    preprocessor mode.

# Ccache 3.3.4 {#_ccache_3_3_4}

Release date: 2017-02-17

## New features and enhancements {#_new_features_and_enhancements_4}

-   Documented the different cache statistics counters.

## Bug fixes {#_bug_fixes_53}

-   Fixed a regression in ccache 3.3 related to potentially bad content
    of dependency files when compiling identical source code but with
    different source paths. This was only partially fixed in 3.3.2 and
    reverts the new "Names of included files are no longer included in
    the hash of the compiler's preprocessed output" feature in 3.3.

-   Corrected statistics counter for `-optf`/`--options-file` failure.

-   Fixed undefined behavior warnings in ccache found by
    `-fsanitize=undefined`.

# Ccache 3.3.3 {#_ccache_3_3_3}

Release date: 2016-10-26

## Bug fixes {#_bug_fixes_54}

-   ccache now detects usage of `.incbin` assembler directives in the
    source code and avoids caching such compilations.

# Ccache 3.3.2 {#_ccache_3_3_2}

Release date: 2016-09-28

## Bug fixes {#_bug_fixes_55}

-   Fixed a regression in ccache 3.3 related to potentially bad content
    of dependency files when compiling identical source code but with
    different source paths.

-   Fixed a regression in ccache 3.3.1: ccache could get confused when
    using the compiler option `-Wp,` to pass multiple options to the
    preprocessor, resulting in missing dependency files from direct mode
    cache hits.

# Ccache 3.3.1 {#_ccache_3_3_1}

Release date: 2016-09-07

## Bug fixes {#_bug_fixes_56}

-   Fixed a problem in the "multiple `-arch` options" support introduced
    in 3.3. When using the direct mode (the default), different
    combinations of `-arch` options were not detected properly.

-   Fixed an issue when compiler option `-Wp,-MT,path` is used instead
    of `-MT path` (and similar for `-MF`, `-MP` and `-MQ`) and
    `run_second_cpp` (`CCACHE_CPP2`) is enabled.

# Ccache 3.3 {#_ccache_3_3}

Release date: 2016-08-27

## Notes {#_notes}

-   A C99-compatible compiler is now required to build ccache.

## New features and enhancements {#_new_features_and_enhancements_5}

-   The configuration option `run_second_cpp` (`CCACHE_CPP2`) now
    defaults to true. This improves ccache's out-of-the-box experience
    for compilers that can't compile their own preprocessed output with
    the same outcome as if they compiled the real source code directly,
    e.g. newer versions of GCC and Clang.

-   The configuration option `hash_dir` (`CCACHE_HASHDIR`) now defaults
    to true.

-   Added a new `ignore_headers_in_manifest` configuration option, which
    specifies headers that should be ignored in the direct mode.

-   Added a new `prefix_command_cpp` (`CCACHE_PREFIX_CPP`) configuration
    option, which specifies one or several prefixes to add to the
    command line ccache uses when invoking the preprocessor.

-   Added a new `limit_multiple` (`CCACHE_LIMIT_MULTIPLE`) configuration
    option, which specifies how much of the cache to remove when
    cleaning.

-   Added a new `keep_comments_cpp` (`CCACHE_COMMENTS`) configuration
    option, which tells ccache not to discard the comments before
    hashing preprocessor output. This can be used to check documentation
    with `-Wdocumentation`.

-   Added a new sloppiness option `no_system_headers`, which tells
    ccache not to include system headers in manifest files.

-   Added a new statistics counter that tracks the number of performed
    cleanups due to the cache size being over the limit. The value is
    shown in the output of "ccache -s".

-   Added support for relocating debug info directory using
    `-fdebug-prefix-map`. This allows for cache hits even when
    `hash_dir` is used in combination with `base_dir`.

-   Added a new "cache hit rate" field to the output of "ccache -s".

-   Added support for caching compilation of assembler code produced by
    e.g. "gcc -S file.c".

-   Added support for cuda including the -optf/--options-file option.

-   Added support for Fortran 77.

-   Added support for multiple `-arch` options to produce "fat
    binaries".

-   Multiple identical `-arch` arguments are now handled without
    bailing.

-   The concatenated form of some long compiler options is now
    recognized, for example when using `-isystemPATH` instead of
    `-isystem PATH`.

-   If hard-linking is enabled and but fails (e.g. due to cross-device
    linking), ccache now falls back to copying instead of running the
    compiler.

-   Made the `hash_dir` option only have effect when generating debug
    info.

-   ccache now knows how to convert absolute paths to relative paths
    inside dependency files when using `base_dir`.

-   Improved parsing of `-g*` options.

-   Made ccache understand `-Wp,-D*` options.

-   ccache now understands the undocumented `-coverage` (only one dash)
    GCC option.

-   Names of included files are no longer included in the hash of the
    compiler's preprocessed output. This leads to more potential cache
    hits when not using the direct mode.

-   Increased buffer size used when reading file data. This improves
    performance slightly.

## Bug fixes {#_bug_fixes_57}

-   Bail out on too hard compiler option `-P`.

-   Fixed Clang test suite when running on Linux.

-   Fixed build and test for MinGW32 and Windows.

# Ccache 3.2.9 {#_ccache_3_2_9}

Release date: 2016-09-28

## Bug fixes {#_bug_fixes_58}

-   Fixed a regression in ccache 3.2.8: ccache could get confused when
    using the compiler option `-Wp,` to pass multiple options to the
    preprocessor, resulting in missing dependency files from direct mode
    cache hits.

# Ccache 3.2.8 {#_ccache_3_2_8}

Release date: 2016-09-07

## Bug fixes {#_bug_fixes_59}

-   Fixed an issue when compiler option `-Wp,-MT,path` is used instead
    of `-MT path` (and similar for `-MF`, `-MP` and `-MQ`) and
    `run_second_cpp` (`CCACHE_CPP2`) is enabled.

-   ccache now understands the undocumented `-coverage` (only one dash)
    GCC option.

# Ccache 3.2.7 {#_ccache_3_2_7}

Release date: 2016-07-20

## Bug fixes {#_bug_fixes_60}

-   Fixed a bug which could lead to false cache hits for compiler
    command lines with a missing argument to an option that takes an
    argument.

-   ccache now knows how to work around a glitch in the output of GCC
    6's preprocessor.

# Ccache 3.2.6 {#_ccache_3_2_6}

Release date: 2016-07-12

## Bug fixes {#_bug_fixes_61}

-   Fixed build problem on QNX, which lacks "SA_RESTART".

-   Bail out on compiler option `-fstack-usage` since it creates a `.su`
    file which ccache currently doesn't handle.

-   Fixed a bug where (due to ccache rewriting paths) the compiler could
    choose incorrect include files if `CCACHE_BASEDIR` is used and the
    source file path is absolute and is a symlink.

# Ccache 3.2.5 {#_ccache_3_2_5}

Release date: 2016-04-17

## New features and enhancements {#_new_features_and_enhancements_6}

-   Only pass Clang-specific `-stdlib=` to the preprocessor.

-   Improved handling of stale NFS handles.

-   Made it harder to misinterpret documentation of boolean environment
    settings\' semantics.

## Bug fixes {#_bug_fixes_62}

-   Include m4 files used by configure.ac in the source dist archives.

-   Corrected "Performance" section in the manual regarding `_DATE`,
    `__TIME__` and `__FILE__` macros.

-   Fixed build on Solaris 10+ and AIX 7.

-   Fixed failure to create directories on QNX.

-   Don't (try to) update manifest file in "read-only" and "read-only
    direct" modes.

-   Fixed a bug in caching of `stat` system calls in "file_stat_matches
    sloppiness mode".

-   Fixed bug in hashing of Clang plugins, leading to unnecessary cache
    misses.

-   Fixed --print-config to show "pch_defines sloppiness".

-   The man page is now built when running "make install" from Git
    repository sources.

# Ccache 3.2.4 {#_ccache_3_2_4}

Release date: 2015-10-08

## Bug fixes {#_bug_fixes_63}

-   Fixed build error related to zlib on systems with older make
    versions (regression in ccache 3.2.3).

-   Made conversion-to-bool explicit to avoid build warnings (and
    potential runtime errors) on legacy systems.

-   Improved signal handling: Kill compiler on SIGTERM; wait for
    compiler to exit before exiting; die appropriately.

-   Minor fixes related to Windows support.

-   The correct compression level is now used if compression is
    requested.

-   Fixed a bug where cache cleanup could be run too early for caches
    larger than 64 GiB on 32-bit systems.

# Ccache 3.2.3 {#_ccache_3_2_3}

Release date: 2015-08-16

## New features and enhancements {#_new_features_and_enhancements_7}

-   Added support for compiler option `-gsplit-dwarf`.

## Bug fixes {#_bug_fixes_64}

-   Support external zlib in nonstandard directory.

-   Avoid calling `exit()` inside an exit handler.

-   Let exit handler terminate properly.

-   Bail out on compiler option `--save-temps` in addition to
    `-save-temps`.

-   Only log "Disabling direct mode" once when failing to read potential
    include files.

# Ccache 3.2.2 {#_ccache_3_2_2}

Release date: 2015-05-10

## New features and enhancements {#_new_features_and_enhancements_8}

-   Added support for `CCACHE_COMPILERCHECK=string:<value>`. This is a
    faster alternative to `CCACHE_COMPILERCHECK=<command>` if the
    command's output can be precalculated by the build system.

-   Add support for caching code coverage results (compiling for gcov).

## Bug fixes {#_bug_fixes_65}

-   Made hash of cached result created with and without `CCACHE_CPP2`
    different. This makes it possible to rebuild with `CCACHE_CPP2` set
    without having to clear the cache to get new results.

-   Don't try to reset a nonexistent stats file. This avoids "No such
    file or directory" messages in the ccache log when the cache
    directory doesn't exist.

-   Fixed a bug where ccache deleted Clang diagnostics after compiler
    failures.

-   Avoid performing an unnecessary copy of the object file on a cache
    miss.

-   Bail out on too hard compiler option `-fmodules`.

-   Bail out on too hard compiler option `-fplugin=libcc1plugin`
    (interaction with GDB).

-   Fixed build error when compiling ccache with recent Clang versions.

-   Removed signal-unsafe code from signal handler.

-   Corrected logic for when to output cached stderr.

-   Wipe the whole cached result on failure retrieving a cached file.

-   Fixed build error when compiling ccache with recent Clang versions.

# Ccache 3.2.1 {#_ccache_3_2_1}

Release date: 2014-12-10

## Bug fixes {#_bug_fixes_66}

-   Fixed regression in temporary file handling, which lead to incorrect
    permissions for stats, manifest and ccache.conf files in the cache.

-   `CACHEDIR.TAG` files are now created in the \[0-9a-f\]
    subdirectories so that ccache.conf is not lost in backups.

-   Made the default cache size suffix `G`, as previously documented.

-   `-fdiagnostics-color=auto` is now passed to the compiler even if
    stderr is redirected. This fixes a problem when, for instance, a
    configure test probes if the compiler (wrapped via ccache) supports
    `-fdiagnostics-color=auto`.

-   Added missing documentation for `max_files` and `max_size`
    configuration options.

# Ccache 3.2 {#_ccache_3_2}

Release date: 2014-11-17

## New features and enhancements {#_new_features_and_enhancements_9}

-   Added support for configuring ccache via one or several
    configuration files instead of via environment variables.
    Environment variables still have priority but are no longer the
    recommended way of customizing ccache behavior. See the manual for
    more information.

-   Added support for compiler error/warning messages with color.

-   Made creation of temporary directories and cache directories smarter
    to avoid unnecessary `stat` calls.

-   Improved efficiency of the algorithm that scans for `_DATE` and
    `__TIME__` tokens in the hashed source code.

-   Added support for several binaries (separated by space) in
    `CCACHE_PREFIX`.

-   The `-c` option is no longer passed to the preprocessor. This fixes
    problems with Clang and Solaris's C++ compiler.

-   ccache no longer passes preprocessor options like `-D` and `-I` to
    the compiler when compiling preprocessed output. This fixes warnings
    emitted by Clang.

-   Compiler options `-fprofile-generate`, `-fprofile-arcs`,
    `-fprofile-use` and `-fbranch-probabilities` are now handled without
    bailing.

-   Added support for Clang's `--serialize-diagnostics` option, storing
    the diagnostics file (`.dia`) in the cache.

-   Added support for precompiled headers when using Clang.

-   Added support for Clang `.pth` (pretokenized header) files.

-   Changed the `-x` language option to use the new objective C standard
    for GCC and Clang.

-   On a cache miss, ccache now instructs the compiler to create the
    object file at the real destination and then copies the file into
    the cache instead of the other way around. This is needed to support
    compiler options like `-fprofile-arcs` and
    `--serialize-diagnostics`.

-   ccache now checks that included files\' ctimes aren't too new. This
    check can be turned off by adding `include_file_ctime` to the
    "ccache sloppiness" setting.

-   Added possibility to get cache hits based on filename, size, mtime
    and ctime only. On other words, source code files are not even read,
    only stat-ed. This operation mode is opt-in by adding
    `file_stat_matches` to the "ccache sloppiness" setting.

-   The filename part of options like `-Wp,-MDfilename` is no longer
    included in the hash since the filename doesn't have any bearing on
    the result.

-   Added a "read-only direct" configuration setting, which is like the
    ordinary read-only setting except that ccache will only try to
    retrieve results from the cache using the direct mode, not the
    preprocessor mode.

-   The display and interpretation of cache size has been changed to use
    SI units.

-   Default cache size is now 5 GB (was previously 1 GiB).

-   Added configuration option to set the compression level of
    compressed object files in the cache.

-   Added support for `@file` and `-@file` arguments (reading options
    from a file).

-   `-Wl,` options are no longer included in the hash since they don't
    affect compilation.

-   Bail out on too hard compiler option `-Wp,-P`.

-   Optimized MD4 calculation code on little-endian systems.

-   Various improvements and fixes on win32.

-   Improved logging to the ccache log file.

-   Added `--dump-manifest` command-line option for debugging purposes.

-   Added `--with-bundled-zlib` configure option.

-   Upgraded bundled zlib to version 1.2.8.

-   Improved `dev.mk` to be more platform independent.

-   Made the test suite work with Clang and gcc-llvm on OS X.

-   Various other improvements of the test suite.

## Bug fixes {#_bug_fixes_67}

-   Any previous `.stderr` is now removed from the cache when recaching.

-   Fixed an issue when handling the `-arch` compiler option with an
    argument.

-   Fixed race condition when creating the initial cache directory.

-   Fixed test suite failures when `CC` is a ccache-wrapped compiler.

# Ccache 3.1.12 {#_ccache_3_1_12}

Release date: 2016-07-12

## Bug fixes {#_bug_fixes_68}

-   Fixed a bug where (due to ccache rewriting paths) the compiler could
    choose incorrect include files if `CCACHE_BASEDIR` is used and the
    source file path is absolute and is a symlink.

# Ccache 3.1.11 {#_ccache_3_1_11}

Release date: 2015-03-07

## Bug fixes {#_bug_fixes_69}

-   Fixed bug which could result in false cache hits when source code
    contains `'"'` followed by `" /*"` or `" //"` (with variations).

-   Made hash of cached result created with and without `CCACHE_CPP2`
    different. This makes it possible to rebuild with `CCACHE_CPP2` set
    without having to clear the cache to get new results.

-   Don't try to reset a nonexistent stats file. This avoids "No such
    file or directory" messages in the ccache log when the cache
    directory doesn't exist.

# Ccache 3.1.10 {#_ccache_3_1_10}

Release date: 2014-10-19

## New features and enhancements {#_new_features_and_enhancements_10}

-   Added support for the `-Xclang` compiler option.

-   Improved handling of exit code of internally executed processes.

-   Zero length object files in the cache are now rejected as invalid.

-   Bail out on option `-gsplit-dwarf` (since it produces multiple
    output files).

-   Compiler option `-fdebug-prefix-map` is now ignored (not part of the
    hash). (The `-fdebug-prefix-map` option may be used in combination
    with `CCACHE_BASEDIR` to reuse results across different
    directories.)

-   Added note in documentation that `--ccache-skip` currently does not
    mean "don't hash the following option".

-   To enable support for precompiled headers (PCH), `CCACHE_SLOPPINESS`
    now also needs to include the new `pch_defines` sloppiness. This is
    because ccache can't detect changes in the source code when only
    defined macros have been changed.

-   Stale files in the internal temporary directory (`<ccache_dir>/tmp`)
    are now cleaned up if they are older than one hour.

## Bug fixes {#_bug_fixes_70}

-   Fixed path canonicalization in `make_relative_path()` when path
    doesn't exist.

-   Fixed bug in `common_dir_prefix_length()`. This corrects the
    `CCACHE_BASEDIR` behavior.

-   ccache no longer tries to create the cache directory when
    `CCACHE_DISABLE` is set.

-   Fixed bug when reading manifests with a very large number of file
    info entries.

-   Fixed problem with logging of current working directory.

# Ccache 3.1.9 {#_ccache_3_1_9}

Release date: 2013-01-06

## Bug fixes {#_bug_fixes_71}

-   The EAGAIN signal is now handled correctly when emitting cached
    stderr output. This fixes a problem triggered by large error outputs
    from the compiler.

-   Subdirectories in the cache are no longer created in read-only mode.

-   Fixed so that ccache's log file descriptor is not made available to
    the compiler.

-   Improved error reporting when failing to create temporary
    stdout/stderr files when executing the compiler.

-   Disappearing temporary stdout/stderr files are now handled
    gracefully.

## Other {#_other_7}

-   Fixed test suite to work on ecryptfs.

# Ccache 3.1.8 {#_ccache_3_1_8}

Release date: 2012-08-11

## New features and enhancements {#_new_features_and_enhancements_11}

-   Made paths to dependency files relative in order to increase cache
    hits.

-   Added work-around to make ccache work with buggy GCC 4.1 when
    creating a pre-compiled header.

-   Clang plugins are now hashed to catch plugin upgrades.

## Bug fixes {#_bug_fixes_72}

-   Fixed crash when the current working directory has been removed.

-   Fixed crash when stderr is closed.

-   Corrected a corner case when parsing backslash escapes in string
    literals.

-   Paths are now correctly canonicalized when computing paths relative
    to the base directory.

## Other {#_other_8}

-   Made git version macro work when compiling outside of the source
    directory.

-   Fixed `static_assert` macro definition clash with GCC 4.7.

# Ccache 3.1.7 {#_ccache_3_1_7}

Release date: 2012-01-08

## Bug fixes {#_bug_fixes_73}

-   Non-writable `CCACHE_DIR` is now handled gracefully when
    `CCACHE_READONLY` is set.

-   Made failure to create files (typically due to bad directory
    permissions) in the cache directory fatal. Previously, such failures
    were silently and erroneously flagged as "compiler produced stdout".

-   Both the `-specs=file` and `--specs=file` forms are now recognized.

-   Added recognition and hashing of GCC plugins specified with
    `-fplugin=file`.

-   `CCACHE_COMPILERCHECK` now also determines how to hash explicit
    specs files (`-specs=file`).

-   Added `CPATH`, `C_INCLUDE_PATH` and similar environment variables to
    the hash to avoid false cache hits when such variables have changed.

-   Corrected log message when unify mode is enabled.

-   Reverted the GCC bug compatibility introduced in ccache 3.1.5 for
    `-MT`/`-MQ` options with concatenated arguments. (The bug is fixed
    in recent GCC versions.)

## Other {#_other_9}

-   Corrected license header for `mdfour.c`.

-   Improved documentation on how to fix bad object files in the cache.

# Ccache 3.1.6 {#_ccache_3_1_6}

Release date: 2011-08-21

## New features and enhancements {#_new_features_and_enhancements_12}

-   Rewrite argument to `--sysroot` if `CCACHE_BASEDIR` is used.

## Bug fixes {#_bug_fixes_74}

-   Don't crash if `getcwd()` fails.

-   Fixed alignment of "called for preprocessing" counter.

# Ccache 3.1.5 {#_ccache_3_1_5}

Release date: 2011-05-29

## New features and enhancements {#_new_features_and_enhancements_13}

-   Added a new statistics counter named "called for preprocessing".

-   The original command line is now logged to the file specified with
    `CCACHE_LOGFILE`.

-   Improved error logging when system calls fail.

-   Added support for rewriting absolute paths in `-F`/`-iframework` GCC
    options.

-   Improved order of statistics counters in `ccache -s` output.

## Bug fixes {#_bug_fixes_75}

-   The `-MF`/`-MT`/`-MQ` options with concatenated argument are now
    handled correctly when they are last on the command line.

-   ccache is now bug compatible with GCC for the `-MT`/`-MQ` options
    with concatenated arguments.

-   Fixed a minor memory leak.

-   Systems that lack (and don't need to be linked with) libm are now
    supported.

# Ccache 3.1.4 {#_ccache_3_1_4}

Release date: 2011-01-09

## Bug fixes {#_bug_fixes_76}

-   Made a work-around for a bug in `gzputc()` in zlib 1.2.5.

-   Corrupt manifest files are now removed so that they won't block
    direct mode hits.

-   ccache now copes with file systems that don't know about symbolic
    links.

-   The file handle is now correctly closed on write error when trying
    to create a cache dir tag.

# Ccache 3.1.3 {#_ccache_3_1_3}

Release date: 2010-11-28

## Bug fixes {#_bug_fixes_77}

-   The -MFarg, -MTarg and -MQarg compiler options (i.e, without space
    between option and argument) are now handled correctly.

## Other {#_other_10}

-   Portability fixes for HP-UX 11.00 and other less common systems.

# Ccache 3.1.2 {#_ccache_3_1_2}

Release date: 2010-11-21

## Bug fixes {#_bug_fixes_78}

-   Bail out on too hard compiler options `-fdump-*`.

-   NULL return values from malloc/calloc of zero bytes are now handled
    correctly.

-   Fixed issue when parsing precompiler output on AIX.

## Other {#_other_11}

-   Improved documentation on which information is included in the hash
    sum.

-   Made the "too new header file" test case work on file systems with
    unsynchronized clocks.

-   The test suite now also works on systems that lack a /dev/zero.

# Ccache 3.1.1 {#_ccache_3_1_1}

Release date: 2010-11-07

## Bug fixes {#_bug_fixes_79}

-   ccache now falls back to preprocessor mode when a non-regular
    include file (device, socket, etc) has been detected so that
    potential hanging due to blocking reads is avoided.

-   CRC errors are now detected when decompressing compressed files in
    the cache.

-   Fixed potential object file corruption race on NFS.

-   Minor documentation corrections.

-   Fixed configure detection of ar.

-   ccache development version (set by dev.mk) now works with gits whose
    `describe` command doesn't understand `--dirty`.

## Other {#_other_12}

-   Minor debug log message improvements.

# Ccache 3.1 {#_ccache_3_1}

Release date: 2010-09-16

## New features and enhancements {#_new_features_and_enhancements_14}

-   Added support for hashing the output of a custom command (e.g.
    `%compiler% --version`) to identify the compiler instead of stat-ing
    or hashing the compiler binary. This can improve robustness when the
    compiler (as seen by ccache) actually isn't the real compiler but
    another compiler wrapper.

-   Added support for caching compilations that use precompiled headers.
    (See the manual for important instructions regarding this.)

-   Locking of the files containing statistics counters is now done
    using symlinks instead of POSIX locks. This should make ccache
    behave a lot better on file systems where POSIX locks are slow or
    broken (e.g. NFS on some systems).

-   Manifest files are now updated without the need of taking locks.

-   Updates of statistics counters are now always done in one of the
    sub-level statistics files. This reduces lock contention, which
    especially improves performance on slow NFS mounts.

-   Reading and writing of statistics counters has been made
    forward-compatible (unknown counters are retained).

-   Files are now read without using `mmap()`. This has two benefits:
    it's more robust against file changes during reading and it improves
    performance on poor systems where `mmap()` doesn't use the disk
    cache.

-   Added `.cp` and `.CP` as known C++ suffixes.

-   Improved logging.

-   Added `-install_name` as an option known to take an argument. (This
    improves statistics when using the Darwin linker.)

## Bug fixes {#_bug_fixes_80}

-   Non-fatal error messages are now never printed to stderr but logged
    instead.

-   Fixed a bug affecting failing commands when `--ccache-skip` is used.

-   Made `--ccache-skip` work for all options.

-   EINTR is now handled correctly.

## Other {#_other_13}

-   Work on porting ccache to win32 (native), mostly done by Ramiro
    Polla. The port is not yet finished, but will hopefully be complete
    in some subsequent release.

-   Added a `--nostats` flag to the performance benchmark program.

-   Made the performance benchmark program more accurate when measuring
    cache hits.

-   Added a new test framework for unit tests written in C.

-   Got rid of `configure-dev`; dev mode is now given by `dev.mk.in`
    presence.

-   Improved documentation on how to combine ccache with other compiler
    wrappers (like `distcc`).

-   New `LICENSE.txt` file with licensing and copyright details about
    bundled source code.

-   New `AUTHORS.txt` file with a list of ccache contributors.

-   New `HACKING.txt` file with some notes about ccache code
    conventions.

# Ccache 3.0.1 {#_ccache_3_0_1}

Release date: 2010-07-15

## Bug fixes {#_bug_fixes_81}

-   The statistics counter "called for link" is now correctly updated
    when linking with a single object file.

-   Fixed a problem with out-of-source builds.

# Ccache 3.0 {#_ccache_3_0}

Release date: 2010-06-20

## General {#_general}

-   ccache is now licensed under the GNU General Public License (GPL)
    version 3 or later.

## Upgrade notes {#_upgrade_notes_3}

-   The way the hashes are calculated has changed, so you won't get
    cache hits for compilation results stored by older ccache versions.
    Because of this, you might as well clear the old cache directory
    with `ccache --clear` if you want, unless you plan to keep using an
    older ccache version.

## New features and enhancements {#_new_features_and_enhancements_15}

-   ccache now has a "direct mode" where it computes a hash of the
    source code (including all included files) and compiler options
    without running the preprocessor. By not running the preprocessor,
    CPU usage is reduced; the speed is somewhere between 1 and 5 times
    that of ccache running in traditional mode, depending on the
    circumstances. The speedup will be higher when I/O is fast (e.g.,
    when files are in the disk cache). The direct mode can be disabled
    by setting CCACHE_NODIRECT.

-   Support has been added for rewriting absolute paths to relative
    paths when hashing, in order to increase cache hit rate when
    building the same source code in different directories even when
    compiling with `-g` and when using absolute include directory paths.
    This is done by setting the `CCACHE_BASEDIR` environment variable to
    an absolute path that specifies which paths to rewrite.

-   Object files are now optionally stored compressed in the cache. The
    runtime cost is negligible, and more files will fit in the ccache
    directory and in the disk cache. Set `CCACHE_COMPRESS` to enable
    object file compression. Note that you can't use compression in
    combination with the hard link feature.

-   A `CCACHE_COMPILERCHECK` option has been added. This option tells
    ccache what compiler-identifying information to hash to ensure that
    results retrieved from the cache are accurate. Possible values are:
    none (don't hash anything), mtime (hash the compiler's mtime and
    size) and content (hash the content of the compiler binary). The
    default is mtime.

-   It is now possible to specify extra files whose contents should be
    included in the hash sum by setting the `CCACHE_EXTRAFILES` option.

-   Added support for Objective-C and Objective-C+\\+. The statistics
    counter "not a C/C++ file" has been renamed to "unsupported source
    language".

-   Added support for the `-x` compiler option.

-   Added support for long command-line options.

-   A `CACHEDIR.TAG` file is now created in the cache directory. See
    <https://bford.info/cachedir>.

-   Messages printed to the debug log (specified by `CCACHE_LOGFILE`)
    have been improved.

-   You can relax some checks that ccache does in direct mode by setting
    `CCACHE_SLOPPINESS`. See the manual for more information.

-   `CCACHE_TEMPDIR` no longer needs to be on the same filesystem as
    `CCACHE_DIR`.

-   The default value of `CCACHE_TEMPDIR` has been changed to
    `$CCACHE_DIR/tmp` to avoid cluttering the top directory.

-   Temporary files that later will be moved into the cache are now
    created in the cache directory they will end up in. This makes
    ccache more friendly to Linux's directory layout.

-   Improved the test suite and added tests for most of the new
    functionality. It's now also possible to specify a subset of tests
    to run.

-   Standard error output from the compiler is now only stored in the
    cache if it's non-empty.

-   If the compiler produces no object file or an empty object file, but
    gives a zero exit status (could be due to a file system problem, a
    buggy program specified by `CCACHE_PREFIX`, etc.), ccache copes with
    it properly.

-   Added `installcheck` and `distcheck` make targets.

-   Clarified cache size limit options\' and cleanup semantics.

-   Improved display of cache max size values.

-   The following options are no longer hashed in the preprocessor mode:
    `-imacros`, `-imultilib`, `-iprefix`, `-iquote`, `-isysroot`,
    `-iwithprefix`, `-iwithprefixbefore`, `-nostdinc`, `-nostdinc++` and
    `-U`.

## Bug fixes {#_bug_fixes_82}

-   Various portability improvements.

-   Improved detection of home directory.

-   User-defined `CPPFLAGS` and `LDFLAGS` are now respected in the
    Makefile.

-   Fixed NFS issues.

-   Computation of the hash sum has been improved to decrease the risk
    of hash collisions. For instance, the compiler options `-X -Y` and
    `-X-Y` previously contributed equally to the hash sum.

-   Bail out on too hard compiler options `--coverage`,
    `-fprofile-arcs`, `-fprofile-generate`, `-fprofile-use`, `-frepo`,
    `-ftest-coverage` and `-save-temps`. Also bail out on `@file` style
    options.

-   Errors when using multiple `-arch` compiler options are now noted as
    "unsupported compiler option".

-   `-MD`/`-MMD` options without `-MT`/`-MF` are now handled correctly.

-   The `-finput-charset` option is now handled correctly.

-   Added support for `-Wp,-MD` and `-Wp,-MMD` options.

-   The compiler options `-Xassembler`, `-b`, `-G` and `-V` are now
    correctly recognized as taking an argument.

-   Debug information containing line numbers of predefined and
    command-line macros (enabled with the compiler option `-g3`) will
    now be correct.

-   Corrected LRU cleanup handling of object files.

-   `utimes()` is now used instead of `utime()` when available.

-   Non-writable cache directories are now handled gracefully.

-   Corrected documentation about sharing the cache directory.

-   Fixed compilation warnings from GCC 4.3.

-   The command specified by `CCACHE_PREFIX` is no longer part of the
    hash.

-   Fixed bad memory access spotted by Valgrind.

-   Fixed a bug in `x_realloc`.

-   Freed memory is no longer referenced when compiling a `.i`/`.ii`
    file and falling back to running the real compiler.

-   The test suite is now immune to external values of the `CCACHE_*`
    environment variables.

-   Improved detection of recursive invocation.

-   The ccache binary is now not unconditionally stripped when
    installing.

-   Statistics counters are now correctly updated for -E option failures
    and internal errors.
